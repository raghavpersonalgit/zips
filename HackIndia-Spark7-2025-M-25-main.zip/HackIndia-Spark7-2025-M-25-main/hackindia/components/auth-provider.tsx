"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { 
  User as FirebaseUser,
  onAuthStateChanged,
  signOut as firebaseSignOut
} from "firebase/auth"
import { 
  auth,
  signInWithEmailAndPassword,
  signUpWithEmail,
  signInWithGoogle,
  getCurrentUser
} from "@/lib/firebase"

type UserRole = "citizen" | "lawyer" | null
type SubscriptionTier = "free" | "premium" | null

interface User {
  id: string
  name: string | null
  email: string | null
  role: UserRole
  subscriptionTier: SubscriptionTier
  subscriptionEndsAt?: Date
  firebaseUser: FirebaseUser
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  loginWithGoogle: () => Promise<void>
  signup: (name: string, email: string, password: string, role: UserRole) => Promise<void>
  logout: () => Promise<void>
  updateSubscription: (tier: SubscriptionTier) => void
  setUserType: (role: UserRole) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [authInitialized, setAuthInitialized] = useState(false)

  // Listen for Firebase auth state changes
  useEffect(() => {
    if (typeof window === 'undefined') return; // Skip on server-side

    // First try to get currently signed-in user
    getCurrentUser()
      .then((firebaseUser) => {
        if (firebaseUser) {
          handleUserData(firebaseUser);
        }
        setAuthInitialized(true);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error("Error getting current user:", error);
        setAuthInitialized(true);
        setIsLoading(false);
      });
      
    // Then set up the auth state change listener
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        handleUserData(firebaseUser);
      } else {
        setUser(null)
      }
      
      setIsLoading(false)
    }, (error) => {
      console.error("Auth state change error:", error);
      setIsLoading(false);
    })

    return () => unsubscribe()
  }, [])

  // Helper function to handle user data
  const handleUserData = (firebaseUser: FirebaseUser) => {
    try {
      // Get stored user data from localStorage
      const storedUserData = localStorage.getItem(`nyay_userdata_${firebaseUser.uid}`)
      let userData: Partial<User> = {}
      
      if (storedUserData) {
        try {
          userData = JSON.parse(storedUserData)
        } catch (e) {
          console.error("Error parsing stored user data:", e)
        }
      }
      
      // Create or update the user object
      const updatedUser: User = {
        id: firebaseUser.uid,
        name: firebaseUser.displayName || userData.name || firebaseUser.email?.split('@')[0] || '',
        email: firebaseUser.email,
        role: userData.role || null,
        subscriptionTier: userData.subscriptionTier || 'free',
        subscriptionEndsAt: userData.subscriptionEndsAt ? new Date(userData.subscriptionEndsAt) : undefined,
        firebaseUser: firebaseUser
      }
      
      setUser(updatedUser)
      
      // Save updated user data
      localStorage.setItem(`nyay_userdata_${firebaseUser.uid}`, JSON.stringify({
        name: updatedUser.name,
        role: updatedUser.role,
        subscriptionTier: updatedUser.subscriptionTier,
        subscriptionEndsAt: updatedUser.subscriptionEndsAt
      }))
    } catch (error) {
      console.error("Error handling user data:", error);
    }
  }

  const login = async (email: string, password: string) => {
    setIsLoading(true)
    try {
      await signInWithEmailAndPassword(email, password)
    } catch (error) {
      console.error("Login error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const loginWithGoogle = async () => {
    setIsLoading(true)
    try {
      await signInWithGoogle()
    } catch (error) {
      console.error("Google login error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const signup = async (name: string, email: string, password: string, role: UserRole) => {
    setIsLoading(true)
    try {
      const firebaseUser = await signUpWithEmail(email, password)

      // Store additional user data
      const userData = {
        name,
        role,
        subscriptionTier: 'free' as SubscriptionTier
      }

      localStorage.setItem(`nyay_userdata_${firebaseUser.uid}`, JSON.stringify(userData))
      
      // Force refresh of user data
      handleUserData(firebaseUser);
    } catch (error) {
      console.error("Signup error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    setIsLoading(true)
    try {
      await firebaseSignOut(auth)
      // Clear user state immediately for better UX
      setUser(null)
    } catch (error) {
      console.error("Error signing out:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const updateSubscription = (tier: SubscriptionTier) => {
    if (!user) return

    try {
      const updatedUser = {
        ...user,
        subscriptionTier: tier,
        ...(tier === "premium" && {
          subscriptionEndsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        }),
      }

      setUser(updatedUser)
      
      // Save updated subscription data
      localStorage.setItem(`nyay_userdata_${user.id}`, JSON.stringify({
        name: updatedUser.name,
        role: updatedUser.role,
        subscriptionTier: updatedUser.subscriptionTier,
        subscriptionEndsAt: updatedUser.subscriptionEndsAt
      }))
    } catch (error) {
      console.error("Error updating subscription:", error)
    }
  }

  const setUserType = (role: UserRole) => {
    if (!user) return

    try {
      const updatedUser = {
        ...user,
        role
      }

      setUser(updatedUser)
      
      // Save updated user data
      localStorage.setItem(`nyay_userdata_${user.id}`, JSON.stringify({
        name: updatedUser.name,
        role: updatedUser.role,
        subscriptionTier: updatedUser.subscriptionTier,
        subscriptionEndsAt: updatedUser.subscriptionEndsAt
      }))
    } catch (error) {
      console.error("Error setting user type:", error)
    }
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      isLoading, 
      login, 
      loginWithGoogle, 
      signup, 
      logout, 
      updateSubscription,
      setUserType
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

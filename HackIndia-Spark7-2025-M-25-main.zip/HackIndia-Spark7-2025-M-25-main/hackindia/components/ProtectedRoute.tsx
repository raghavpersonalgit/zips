import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/authContext";

interface ProtectedRouteProps {
  children: React.ReactNode;
  userType?: "citizen" | "lawyer";
}

const ProtectedRoute = ({ children, userType }: ProtectedRouteProps) => {
  const { user, loading, userType: currentUserType } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        // Redirect to login if not authenticated
        router.push("/login");
      } else if (userType && userType !== currentUserType) {
        // Redirect to home if authenticated but wrong user type
        router.push("/");
      }
    }
  }, [user, loading, router, userType, currentUserType]);

  // Show nothing while loading or redirecting
  if (loading || !user || (userType && userType !== currentUserType)) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  // User is authenticated and has correct user type or no specific user type is required
  return <>{children}</>;
};

export default ProtectedRoute; 
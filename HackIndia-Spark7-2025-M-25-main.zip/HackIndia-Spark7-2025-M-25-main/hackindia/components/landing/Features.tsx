import { motion } from "framer-motion";
import { FileText, Scale, Shield, CheckCircle } from "lucide-react";

const features = [
  {
    id: 1,
    title: "Legal Clarity",
    description: "Simplify complex legal terms and procedures into easy-to-understand language that anyone can follow.",
    icon: <Scale className="h-7 w-7 text-india-green-600" />,
    color: "bg-india-green-100",
    textColor: "text-india-green-600",
  },
  {
    id: 2,
    title: "Document Analysis",
    description: "Upload legal documents for instant analysis, summaries, and extraction of key points and obligations.",
    icon: <FileText className="h-7 w-7 text-saffron-600" />,
    color: "bg-saffron-100",
    textColor: "text-saffron-600",
  },
  {
    id: 3,
    title: "Multilingual Support",
    description: "Access legal help in multiple Indian languages including Hindi, English, Punjabi, Tamil, and more.",
    icon: <Shield className="h-7 w-7 text-blue-600" />,
    color: "bg-blue-100",
    textColor: "text-blue-600",
  },
];

const Features = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="py-24 relative overflow-hidden bg-gray-50">
      {/* Decorative elements */}
      <div className="absolute -left-20 top-1/4 w-40 h-40 rounded-full bg-saffron-500/5 blur-3xl" />
      <div className="absolute -right-20 bottom-1/4 w-40 h-40 rounded-full bg-india-green-500/5 blur-3xl" />
      
      <div className="container px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-saffron-100 text-saffron-800 text-sm font-medium mb-4">
              <span className="w-2 h-2 rounded-full bg-saffron-500 mr-2"></span>
              Features
            </div>
            <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-gray-900">AI for Bharat 🇮🇳</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Legal assistance powered by artificial intelligence, designed specifically for India's diverse needs
            </p>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            {features.map((feature) => (
              <motion.div
                key={feature.id}
                variants={itemVariants}
                className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100"
              >
                <div className={`w-16 h-16 rounded-2xl ${feature.color} flex items-center justify-center mb-6`}>
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {feature.description}
                </p>
                <div className="flex items-center">
                  <CheckCircle className={`h-5 w-5 ${feature.textColor} mr-2`} />
                  <span className="text-sm font-medium text-gray-600">Powered by AI</span>
                </div>
              </motion.div>
            ))}
          </motion.div>
          
          <motion.div 
            className="mt-20"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-white p-4">
              <div className="absolute top-2 left-2 flex space-x-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <img 
                src="/features.png" 
                alt="AI for Bharat Features" 
                className="w-full h-auto rounded-xl"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Features; 
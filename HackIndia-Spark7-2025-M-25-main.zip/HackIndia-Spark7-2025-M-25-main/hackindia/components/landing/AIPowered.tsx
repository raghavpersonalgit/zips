import { motion } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";
import Link from "next/link";

const features = [
  "Analyze legal documents instantly",
  "Get answers to complex legal questions",
  "Receive guidance in multiple languages",
  "Compare clauses across different documents"
];

const AIPowered = () => {
  return (
    <section className="py-24 bg-white relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute left-0 top-1/4 w-64 h-64 bg-blue-50 rounded-full blur-3xl opacity-70" />
      <div className="absolute right-0 bottom-1/3 w-96 h-96 bg-saffron-50 rounded-full blur-3xl opacity-70" />
      
      <div className="container px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 text-gray-800 text-sm font-medium mb-4">
                AI Powered
              </span>
              <h2 className="text-4xl font-bold mb-6">Rapid Analysis & Research</h2>
              <p className="text-xl text-gray-600 mb-8">
                Complete hours of legal research and document analysis in seconds with our advanced AI technology.
              </p>

              <div className="space-y-5 mb-10">
                {features.map((feature, index) => (
                  <motion.div 
                    key={index} 
                    className="flex items-start"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <div className="flex-shrink-0 mt-1">
                      <div className="w-5 h-5 rounded-full bg-india-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-india-green-600" />
                      </div>
                    </div>
                    <p className="ml-3 text-gray-700">{feature}</p>
                  </motion.div>
                ))}
              </div>

              <Link 
                href="/chat"
                className="group inline-flex items-center text-india-green-600 font-medium hover:text-india-green-700 transition-all"
              >
                Try it now
                <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="relative">
                <div className="absolute -top-6 -left-6 w-12 h-12 rounded-full bg-saffron-100 flex items-center justify-center shadow-lg z-10">
                  <span className="text-saffron-500 font-bold">AI</span>
                </div>
                
                <div className="bg-white rounded-xl border border-gray-200 shadow-2xl overflow-hidden">
                  <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h3 className="font-semibold">Ask AI Lawyer</h3>
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 rounded-full bg-gray-300"></div>
                      <div className="w-2 h-2 rounded-full bg-gray-300"></div>
                      <div className="w-2 h-2 rounded-full bg-gray-300"></div>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="bg-gray-100 rounded-lg p-4 mb-4">
                      <p className="text-gray-700">What are my rights as an Indian citizen?</p>
                    </div>
                    
                    <div className="bg-india-green-50 rounded-lg p-4 border-l-4 border-india-green-500">
                      <motion.div
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: 0.6 }}
                      >
                        <p className="text-gray-700">As an Indian citizen, you have fundamental rights guaranteed by the Constitution of India, including:</p>
                        <ul className="list-disc pl-5 mt-2 space-y-1 text-gray-700">
                          <motion.li 
                            initial={{ opacity: 0, x: 5 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.3, delay: 0.7 }}
                          >
                            Right to Equality (Articles 14-18)
                          </motion.li>
                          <motion.li 
                            initial={{ opacity: 0, x: 5 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.3, delay: 0.8 }}
                          >
                            Right to Freedom (Articles 19-22)
                          </motion.li>
                          <motion.li 
                            initial={{ opacity: 0, x: 5 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.3, delay: 0.9 }}
                          >
                            Right against Exploitation (Articles 23-24)
                          </motion.li>
                          <motion.li 
                            initial={{ opacity: 0, x: 5 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.3, delay: 1.0 }}
                          >
                            Right to Freedom of Religion (Articles 25-28)
                          </motion.li>
                          <motion.li 
                            initial={{ opacity: 0, x: 5 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.3, delay: 1.1 }}
                          >
                            Cultural and Educational Rights (Articles 29-30)
                          </motion.li>
                          <motion.li 
                            initial={{ opacity: 0, x: 5 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.3, delay: 1.2 }}
                          >
                            Right to Constitutional Remedies (Article 32)
                          </motion.li>
                        </ul>
                      </motion.div>
                    </div>
                  </div>
                </div>
                
                {/* Decorative elements */}
                <div className="absolute -bottom-5 -right-5 w-20 h-20 bg-india-green-50 rounded-full blur-xl"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIPowered; 
import { motion } from "framer-motion";
import { ArrowRight, Globe, Smartphone, AppWindow } from "lucide-react";
import Link from "next/link";

const platforms = [
  {
    id: 1,
    title: "Web App",
    description: "Access through any modern browser on desktop or mobile. No download required.",
    icon: <Globe className="h-8 w-8 text-white" />,
    link: "#",
    status: "Available now",
    color: "from-blue-500 to-blue-600"
  },
  {
    id: 2,
    title: "iOS App",
    description: "Native application for iPhone and iPad devices with offline capabilities.",
    icon: <Smartphone className="h-8 w-8 text-white" />,
    link: "#",
    status: "Coming soon",
    color: "from-saffron-500 to-saffron-600"
  },
  {
    id: 3,
    title: "Android App",
    description: "Available on Google Play for all Android devices with enhanced features.",
    icon: <AppWindow className="h-8 w-8 text-white" />,
    link: "#",
    status: "Coming soon",
    color: "from-india-green-500 to-india-green-600"
  }
];

const MultiPlatform = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="py-28 bg-gradient-to-br from-gray-900 to-black text-white relative overflow-hidden">
      {/* Decorative background with gradient mesh */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(249,115,22,0.15),transparent_50%)]"></div>
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_80%,rgba(19,136,8,0.15),transparent_50%)]"></div>
      </div>
      
      {/* Grid pattern */}
      <div className="absolute inset-0 bg-[url('/grid-pattern.svg')] opacity-10"></div>
      
      <div className="container px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm text-white text-sm font-medium mb-4 border border-white/10">
              Accessibility
            </span>
            <h2 className="text-4xl font-bold mb-4">Access Anywhere, Anytime</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Swaraj.ai is available across multiple platforms so you can get legal assistance wherever you are
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            {platforms.map((platform) => (
              <motion.div
                key={platform.id}
                variants={itemVariants}
                className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300 group"
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <div className="mb-6">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${platform.color} flex items-center justify-center shadow-lg shadow-black/20 group-hover:shadow-lg group-hover:shadow-black/40 transition-all`}>
                    {platform.icon}
                  </div>
                </div>
                <h3 className="text-2xl font-bold mb-3">{platform.title}</h3>
                <p className="text-gray-300 mb-6">
                  {platform.description}
                </p>
                <Link 
                  href={platform.link}
                  className="inline-flex items-center text-saffron-400 font-medium hover:text-saffron-300 group"
                >
                  {platform.status}
                  <motion.span 
                    className="ml-2"
                    initial={{ x: 0 }}
                    whileHover={{ x: 3 }}
                  >
                    <ArrowRight className="h-4 w-4" />
                  </motion.span>
                </Link>
              </motion.div>
            ))}
          </motion.div>
          
          <motion.div 
            className="mt-16 text-center"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="inline-flex items-center space-x-2 py-2 px-4 rounded-full bg-white/5 border border-white/10">
              <span className="w-2 h-2 rounded-full bg-india-green-500"></span>
              <span className="text-sm text-gray-300">30,000+ happy users and counting</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default MultiPlatform; 
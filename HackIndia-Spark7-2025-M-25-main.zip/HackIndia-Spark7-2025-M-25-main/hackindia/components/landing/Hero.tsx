import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const Hero = () => {
  return (
    <section className="relative w-full min-h-screen overflow-hidden">
      {/* Background elements */}
      <div
        className="absolute inset-0 bg-gradient-to-br from-black to-gray-900"
        style={{
          backgroundImage: "url('/swaraj-gradient-bg.svg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.9,
        }}
      />
      
      {/* Animated overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px]" />
        
        {/* Abstract shapes */}
        <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-saffron-500/10 blur-3xl" />
        <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full bg-india-green-500/10 blur-3xl" />
      </div>

      <div className="container relative z-10 px-4 py-20 h-full flex flex-col justify-center">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-sm text-white text-sm font-medium mb-6 border border-white/20">
              <span className="flex h-2 w-2 rounded-full bg-saffron-500 mr-2"></span>
              India's First Multilingual AI Legal Platform
            </div>
            
            <h1 className="text-6xl sm:text-7xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-white/80 mb-6">
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.8 }}
                className="inline-block"
              >
                Swaraj
              </motion.span>
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.8 }}
                className="inline-block text-transparent bg-clip-text bg-gradient-to-r from-saffron-400 to-saffron-500"
              >
                .ai
              </motion.span>
            </h1>
            
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9, duration: 0.8 }}
              className="text-xl sm:text-2xl text-white/90 font-medium max-w-3xl mx-auto leading-relaxed"
            >
              Democratic access to legal assistance through AI
            </motion.p>
          </motion.div>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="text-white/70 text-lg max-w-2xl mx-auto mb-12 text-center"
          >
            Empowering citizens, lawyers, and organizations across Bharat with AI-powered legal assistance in multiple regional languages.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link
              href="/chat"
              className="group relative inline-flex h-14 overflow-hidden rounded-lg bg-white px-8 py-3 hover:bg-gray-100 focus:outline-none focus:ring focus:ring-saffron-400/50"
            >
              <span className="absolute right-0 -mt-12 h-32 w-8 translate-x-12 rotate-12 transform bg-saffron-400/10 opacity-10 transition-transform duration-700 ease-in-out group-hover:-translate-x-40"></span>
              <span className="relative flex items-center justify-center font-medium text-gray-900 text-lg">
                Try Now
              </span>
            </Link>
            
            <Link
              href="/signup"
              className="group relative inline-flex h-14 overflow-hidden rounded-lg bg-gradient-to-r from-saffron-500 to-saffron-600 px-8 py-3 hover:from-saffron-600 hover:to-saffron-700 focus:outline-none focus:ring focus:ring-saffron-400/50"
            >
              <span className="absolute right-0 -mt-12 h-32 w-8 translate-x-12 rotate-12 transform bg-white opacity-10 transition-transform duration-700 ease-in-out group-hover:-translate-x-40"></span>
              <span className="relative flex items-center justify-center font-medium text-white text-lg">
                Sign Up Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </span>
            </Link>
            
            <Link
              href="/login"
              className="inline-flex items-center justify-center h-14 px-8 bg-transparent text-white border border-white/30 rounded-lg font-medium text-lg hover:bg-white/5 transition-all hover:border-white/50"
            >
              Login
            </Link>
          </motion.div>
          
          {/* Trust indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.8, duration: 0.8 }}
            className="mt-20 pt-10 text-center"
          >
            <p className="text-white/60 text-sm mb-4">Trusted by lawyers and citizens across India</p>
            <div className="flex justify-center space-x-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="w-2 h-2 rounded-full bg-white/30"></div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero; 
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Link from "next/link";

const CTASection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-saffron-50 via-white to-india-green-50"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-20 bg-gradient-to-b from-white to-transparent"></div>
      <div className="absolute -left-10 top-1/3 w-32 h-32 bg-saffron-500/20 rounded-full blur-3xl"></div>
      <div className="absolute -right-10 bottom-1/3 w-32 h-32 bg-india-green-500/20 rounded-full blur-3xl"></div>
      
      {/* Grid pattern */}
      <div className="absolute inset-0 bg-[url('/grid-pattern-light.svg')] opacity-5"></div>
      
      <div className="container px-4 relative z-10">
        <motion.div 
          className="max-w-5xl mx-auto text-center bg-white/70 backdrop-blur-sm rounded-3xl p-12 shadow-xl border border-gray-100"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-india-green-100 text-india-green-800 text-sm font-semibold mb-6 border border-india-green-200">
              <span className="flex items-center justify-center w-5 h-5 rounded-full bg-india-green-500 text-white mr-2 text-xs">✓</span>
              No credit card required
            </div>
          </motion.div>
          
          <motion.h2 
            className="text-4xl sm:text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Smart Legal Help for Every Citizen
          </motion.h2>
          
          <motion.p 
            className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            Join thousands of users who are already benefiting from Swaraj.ai's 
            intelligent legal assistance in the language of their choice.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Link 
              href="/signup" 
              className="group relative inline-flex h-14 overflow-hidden rounded-lg bg-gradient-to-r from-india-green-600 to-india-green-700 px-10 py-3 hover:from-india-green-700 hover:to-india-green-800 focus:outline-none focus:ring focus:ring-india-green-400/50"
            >
              <span className="absolute right-0 -mt-12 h-32 w-8 translate-x-12 rotate-12 transform bg-white opacity-10 transition-transform duration-700 ease-in-out group-hover:-translate-x-40"></span>
              <span className="relative flex items-center justify-center font-medium text-white text-lg">
                Get Started 
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </span>
            </Link>
            
            <Link 
              href="/chat" 
              className="inline-flex items-center justify-center h-14 px-10 bg-white text-gray-900 rounded-lg font-medium text-lg hover:bg-gray-50 transition-all shadow-lg border border-gray-100"
            >
              Try Demo
            </Link>
          </motion.div>
          
          <motion.div 
            className="mt-12 pt-8 border-t border-gray-200 flex flex-col sm:flex-row items-center justify-center gap-8"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="flex items-center gap-3">
              <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center overflow-hidden">
                    <span className="text-xs font-semibold text-gray-600">{i}</span>
                  </div>
                ))}
              </div>
              <p className="text-gray-500 text-sm font-medium">Join 5,000+ Users</p>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((i) => (
                  <svg 
                    key={i}
                    className="w-4 h-4 text-saffron-500" 
                    fill="currentColor" 
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-500 text-sm font-medium">4.9/5 Rating</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection; 
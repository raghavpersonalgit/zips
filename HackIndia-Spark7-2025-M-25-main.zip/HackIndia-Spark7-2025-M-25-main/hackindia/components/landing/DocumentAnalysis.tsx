import { motion } from "framer-motion";
import { FileText, Check, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const documents = [
  { name: "Legal_claim.pdf", size: "1,045KB" },
  { name: "Legal_claim2.pdf", size: "854KB" }
];

const features = [
  "Extract key clauses and obligations",
  "Compare documents side by side",
  "Flag potential issues and risks",
  "Summarize lengthy documents in seconds"
];

const DocumentAnalysis = () => {
  return (
    <section className="py-24 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-20 bg-gradient-to-b from-gray-100 to-transparent"></div>
      <div className="absolute -left-40 top-1/3 w-80 h-80 bg-india-green-50 rounded-full blur-[100px]"></div>
      <div className="absolute -right-40 bottom-1/3 w-80 h-80 bg-saffron-50 rounded-full blur-[100px]"></div>
      
      <div className="container px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              className="order-2 md:order-1"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6 }}
            >
              <div className="bg-white rounded-xl shadow-xl p-8 border border-gray-200 relative overflow-hidden">
                {/* Decorative dot pattern */}
                <div className="absolute top-0 right-0 w-20 h-20 opacity-5">
                  <div className="w-full h-full flex flex-wrap">
                    {Array(16).fill(0).map((_, i) => (
                      <div key={i} className="w-1/4 h-1/4 flex items-center justify-center">
                        <div className="w-1 h-1 rounded-full bg-black"></div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <h3 className="text-2xl font-bold mb-4">AI document handling</h3>
                <p className="text-gray-600 mb-8">
                  The fastest way to summarize agreements, extract key information, and understand complex legal documents.
                </p>
                
                <div className="space-y-4 mb-6">
                  {documents.map((doc, index) => (
                    <motion.div 
                      key={index} 
                      className="flex items-center gap-3 p-4 rounded-lg border border-gray-200 hover:border-india-green-200 hover:bg-india-green-50/30 transition-all cursor-pointer group"
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.3, delay: 0.2 + index * 0.1 }}
                      whileHover={{ scale: 1.01 }}
                    >
                      <div className="flex-shrink-0 text-gray-400 group-hover:text-india-green-600 transition-colors">
                        <FileText className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-medium group-hover:text-india-green-700 transition-colors">{doc.name}</p>
                        <p className="text-sm text-gray-500">{doc.size}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
                
                <Button className="w-full bg-black text-white hover:bg-gray-800 h-12 rounded-lg font-medium">
                  Compare with AI
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </motion.div>
            
            <motion.div
              className="order-1 md:order-2"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 text-gray-800 text-sm font-medium mb-4">
                Document Analysis
              </span>
              <h2 className="text-4xl font-bold mb-6">Smart Legal Document Processing</h2>
              <p className="text-xl text-gray-600 mb-8">
                Upload contracts, agreements, and legal documents for instant AI-powered analysis and comparison.
              </p>
              
              <div className="space-y-5">
                {features.map((feature, index) => (
                  <motion.div 
                    key={index} 
                    className="flex items-center"
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: 0.4 + index * 0.1 }}
                  >
                    <div className="flex-shrink-0">
                      <div className="w-6 h-6 rounded-full bg-india-green-100 flex items-center justify-center">
                        <Check className="h-4 w-4 text-india-green-600" />
                      </div>
                    </div>
                    <p className="ml-3 text-gray-700">{feature}</p>
                  </motion.div>
                ))}
              </div>
              
              <motion.div
                className="mt-10 pl-4 border-l-2 border-saffron-300"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.8 }}
              >
                <p className="text-gray-600 italic">
                  "The document analysis feature saved us hours of work reviewing contracts. Highly recommended for any legal team."
                </p>
                <p className="text-sm font-medium mt-2">— Advocate Sharma, Delhi High Court</p>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DocumentAnalysis; 
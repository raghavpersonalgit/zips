import { motion } from "framer-motion";
import { Scale, User, Building2, BookOpen } from "lucide-react";

const categories = [
  {
    id: 1,
    title: "For Legal Consumers",
    description: "From deciphering complex terms to understanding rights, we've got you covered.",
    icon: <User className="h-6 w-6 text-white" />,
    gradient: "from-blue-500 to-blue-600",
    highlights: ["User-friendly interface", "Plain language explanations", "Rights awareness"]
  },
  {
    id: 2,
    title: "For Lawyers",
    description: "Streamline research, document review, and case preparation with powerful AI tools.",
    icon: <Scale className="h-6 w-6 text-white" />,
    gradient: "from-saffron-500 to-saffron-600",
    highlights: ["Advanced legal research", "Document parsing", "Precedent matching"]
  },
  {
    id: 3,
    title: "For Law Firms",
    description: "Enhance productivity and service quality across your entire practice.",
    icon: <Building2 className="h-6 w-6 text-white" />,
    gradient: "from-india-green-500 to-india-green-600",
    highlights: ["Team collaboration", "Knowledge management", "Client service"]
  },
  {
    id: 4,
    title: "For Law Students",
    description: "Learn faster and more effectively with AI-powered study assistance.",
    icon: <BookOpen className="h-6 w-6 text-white" />,
    gradient: "from-purple-500 to-purple-600",
    highlights: ["Exam preparation", "Case study analysis", "Legal concept explanation"]
  },
];

const UserCategories = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="py-28 bg-gradient-to-br from-gray-900 to-black text-white relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-saffron-500/10 blur-[100px] rounded-full" />
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-india-green-500/10 blur-[100px] rounded-full" />
      
      <div className="container px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm text-white mb-6 border border-white/10">
              <span className="inline-block w-3 h-3 rounded-full bg-blue-500 mr-2"></span>
              <span>Users</span>
            </div>
            <h2 className="text-5xl font-bold mb-6">Who is AI Lawyer for?</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Explore features that boost your productivity. From document automation
              to advanced research, we've got the hard work covered.
            </p>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            {categories.map((category) => (
              <motion.div
                key={category.id}
                variants={itemVariants}
                className="bg-gray-800 rounded-xl p-6 h-full border border-gray-700/50 backdrop-blur-sm hover:bg-gray-800/80 transition-all duration-300"
                whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
              >
                <div className="flex flex-col h-full">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${category.gradient} flex items-center justify-center mb-5 shadow-lg`}>
                    {category.icon}
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-3">{category.title}</h3>
                  <p className="text-gray-400 mb-6">{category.description}</p>
                  
                  <div className="mt-auto">
                    <div className="pt-4 border-t border-gray-700/50">
                      <ul className="space-y-2">
                        {category.highlights.map((highlight, index) => (
                          <li key={index} className="flex items-center text-sm text-gray-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-2"></span>
                            {highlight}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default UserCategories; 
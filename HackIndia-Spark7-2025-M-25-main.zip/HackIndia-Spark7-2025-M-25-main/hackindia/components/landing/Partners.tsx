import { motion } from "framer-motion";

const partners = [
  { id: 1, name: "Partner 1", logoUrl: "/coursel/Screenshot 2025-04-30 at 10.15.10 PM.png" },
  { id: 2, name: "Partner 2", logoUrl: "/coursel/Screenshot 2025-04-30 at 10.15.10 PM.png" },
  { id: 3, name: "Partner 3", logoUrl: "/coursel/Screenshot 2025-04-30 at 10.15.56 PM.png" },
  { id: 4, name: "Partner 4", logoUrl: "/coursel/Screenshot 2025-04-30 at 10.15.08 PM.png" },
  { id: 5, name: "Partner 5", logoUrl: "/coursel/Screenshot 2025-04-30 at 10.15.08 PM.png" },
];

const Partners = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute left-0 top-0 w-32 h-32 bg-gray-100 rounded-full blur-3xl opacity-70" />
      <div className="absolute right-0 bottom-0 w-48 h-48 bg-gray-100 rounded-full blur-3xl opacity-70" />
      
      <div className="container px-4 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Trusted by Leading Organizations</h2>
            <p className="text-gray-500">Working together to empower legal accessibility across India</p>
          </div>
          
          <motion.div 
            className="flex flex-wrap justify-center items-center gap-x-16 gap-y-10"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            {partners.map((partner) => (
              <motion.div
                key={partner.id}
                className="w-40 h-20 flex items-center justify-center filter grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all duration-300"
                variants={itemVariants}
              >
                <img 
                  src={partner.logoUrl}
                  alt={partner.name}
                  className="max-h-full max-w-full object-contain"
                  onError={(e) => {
                    e.currentTarget.src = `https://placehold.co/200x80/f8f8f8/aaa?text=Partner+${partner.id}`;
                  }}
                />
              </motion.div>
            ))}
          </motion.div>
          
          <div className="mt-12 pt-8 border-t border-gray-200 text-center">
            <p className="text-sm text-gray-500">
              Join hundreds of organizations that trust Swaraj.ai for their legal needs
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Partners; 
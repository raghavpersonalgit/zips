"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle, MessageSquare, Trash2 } from "lucide-react"
import { motion } from "framer-motion"

type Conversation = {
  id: string
  title: string
  date: Date
  preview: string
}

export default function ChatSidebar() {
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: "1",
      title: "Property Dispute Question",
      date: new Date(2023, 5, 15),
      preview: "I need help with a property dispute...",
    },
    {
      id: "2",
      title: "Tenant Rights in Delhi",
      date: new Date(2023, 5, 10),
      preview: "What are my rights as a tenant in Delhi?",
    },
    {
      id: "3",
      title: "Marriage Registration",
      date: new Date(2023, 5, 5),
      preview: "How do I register my marriage in Punjab?",
    },
  ])

  const [activeConversation, setActiveConversation] = useState<string | null>("1")

  const handleNewChat = () => {
    const newConversation: Conversation = {
      id: Date.now().toString(),
      title: "New Conversation",
      date: new Date(),
      preview: "Start a new conversation...",
    }
    setConversations([newConversation, ...conversations])
    setActiveConversation(newConversation.id)
  }

  const handleDeleteConversation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setConversations(conversations.filter((conv) => conv.id !== id))
    if (activeConversation === id) {
      setActiveConversation(conversations[0]?.id || null)
    }
  }

  return (
    <div className="h-full flex flex-col bg-muted/30 border-r">
      <div className="p-4">
        <Button
          onClick={handleNewChat}
          className="w-full bg-saffron-500 hover:bg-saffron-600 text-white flex items-center justify-center gap-2"
        >
          <PlusCircle size={16} />
          New Chat
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {conversations.map((conversation) => (
          <motion.div
            key={conversation.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className={`sidebar-item cursor-pointer ${activeConversation === conversation.id ? "active" : ""}`}
            onClick={() => setActiveConversation(conversation.id)}
          >
            <MessageSquare size={18} className="text-muted-foreground" />
            <div className="flex-1 overflow-hidden">
              <div className="font-medium truncate">{conversation.title}</div>
              <div className="text-xs text-muted-foreground truncate">{conversation.preview}</div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="opacity-0 group-hover:opacity-100 h-6 w-6"
              onClick={(e) => handleDeleteConversation(conversation.id, e)}
            >
              <Trash2 size={14} className="text-muted-foreground" />
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ModeToggle } from "./mode-toggle"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { LanguageSelector } from "./language-selector"
import { useMobile } from "@/hooks/use-mobile"
import { motion } from "framer-motion"
import { useAuth } from "./auth-provider"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Header() {
  const pathname = usePathname()
  const isMobile = useMobile()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { user, logout } = useAuth()

  // Close mobile menu when changing route
  useEffect(() => {
    setIsMenuOpen(false)
  }, [pathname])

  const navItems = [
    { name: "Home", path: "/" },
    { name: "For Lawyers", path: "/lawyer" },
    { name: "For Citizens", path: "/chat" },
    { name: "Pricing", path: "/pricing" },
    { name: "Reports", path: "/report" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-saffron-500 to-india-green-500">
                Swaraj.ai
              </span>
            </motion.div>
          </Link>
        </div>

        {/* Desktop Navigation */}
        {!isMobile && (
          <nav className="flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  pathname === item.path ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>
        )}

        <div className="flex items-center gap-2">
          <LanguageSelector />
          <ModeToggle />

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {user && user.name ? user.name.charAt(0).toUpperCase() : "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <div className="px-2 py-1.5 text-sm font-medium">
                  {user?.name || 'User'}
                  <div className="text-xs text-muted-foreground">{user?.email || ''}</div>
                  <div className="text-xs mt-1">
                    <span className="bg-saffron-100 text-saffron-800 dark:bg-saffron-900 dark:text-saffron-200 px-1.5 py-0.5 rounded-full text-[10px] font-medium">
                      {user?.role === "lawyer" ? "Lawyer" : "Citizen"}
                    </span>{" "}
                    <span
                      className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${
                        user?.subscriptionTier === "premium"
                          ? "bg-india-green-100 text-india-green-800 dark:bg-india-green-900 dark:text-india-green-200"
                          : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
                      }`}
                    >
                      {user?.subscriptionTier === "premium" ? "Premium" : "Free"}
                    </span>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                {user.role === "lawyer" && (
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard">Dashboard</Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem asChild>
                  <Link href="/chat">Chat</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              {isMobile ? (
                <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Toggle Menu">
                  {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
                </Button>
              ) : (
                <div className="flex items-center gap-2">
                  <Button variant="ghost" asChild>
                    <Link href="/login">Login</Link>
                  </Button>
                  <Button asChild className="bg-india-green-500 hover:bg-india-green-600">
                    <Link href="/signup">Sign Up</Link>
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMobile && isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="container pb-4"
        >
          <nav className="flex flex-col space-y-3">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={`px-2 py-1.5 text-sm font-medium rounded-md transition-colors hover:bg-accent ${
                  pathname === item.path ? "bg-accent text-foreground" : "text-muted-foreground"
                }`}
              >
                {item.name}
              </Link>
            ))}
            {user ? (
              <>
                <Link
                  href="/profile"
                  className="px-2 py-1.5 text-sm font-medium rounded-md transition-colors hover:bg-accent text-muted-foreground"
                >
                  Profile
                </Link>
                <Link
                  href="/chat"
                  className="px-2 py-1.5 text-sm font-medium rounded-md transition-colors hover:bg-accent text-muted-foreground"
                >
                  Chat
                </Link>
                {user.role === "lawyer" && (
                  <Link
                    href="/dashboard"
                    className="px-2 py-1.5 text-sm font-medium rounded-md transition-colors hover:bg-accent text-muted-foreground"
                  >
                    Dashboard
                  </Link>
                )}
                <Button onClick={logout} variant="destructive" className="mt-2">
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Button asChild variant="outline" className="mt-2">
                  <Link href="/login">Login</Link>
                </Button>
                <Button asChild className="mt-2 bg-india-green-500 hover:bg-india-green-600">
                  <Link href="/signup">Sign Up</Link>
                </Button>
              </>
            )}
          </nav>
        </motion.div>
      )}
    </header>
  )
}

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { User, onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";
import { useRouter } from "next/navigation";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAuthenticated: boolean;
  userType: "citizen" | "lawyer" | null;
  setUserType: (type: "citizen" | "lawyer") => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  isAuthenticated: false,
  userType: null,
  setUserType: () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [userType, setUserType] = useState<"citizen" | "lawyer" | null>(null);
  const router = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
      
      // Check localStorage for user type when auth state changes
      if (user) {
        const savedUserType = localStorage.getItem("userType") as "citizen" | "lawyer" | null;
        if (savedUserType) {
          setUserType(savedUserType);
        }
      } else {
        setUserType(null);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleSetUserType = (type: "citizen" | "lawyer") => {
    setUserType(type);
    if (type) {
      localStorage.setItem("userType", type);
    }
  };

  const value = {
    user,
    loading,
    isAuthenticated: !!user,
    userType,
    setUserType: handleSetUserType,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; 
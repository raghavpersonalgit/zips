// Import the functions you need from the SDKs
import { initializeApp, getApps } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword as signInWithEmail,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User,
  setPersistence,
  browserLocalPersistence
} from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDqUG7jGQsWctSZrV3QsXRc5BDOUjK3dYQ",
  authDomain: "nyay-cc6b9.firebaseapp.com",
  projectId: "nyay-cc6b9",
  storageBucket: "nyay-cc6b9.appspot.com",
  messagingSenderId: "244716531932",
  appId: "1:244716531932:web:0a839687c0590a2d5b4419",
  measurementId: "G-NJ2S2TWVEX"
};

// Initialize Firebase
let app;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApps()[0];
}

// Initialize Auth and Analytics
const auth = getAuth(app);

// Set persistence to LOCAL (survives browser restarts)
if (typeof window !== 'undefined') {
  setPersistence(auth, browserLocalPersistence).catch(error => {
    console.error("Error setting auth persistence:", error);
  });
}

const analytics = typeof window !== 'undefined' ? getAnalytics(app) : null;
const googleProvider = new GoogleAuthProvider();

// Configure Google Auth Provider with additional scopes if needed
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

// Authentication Helper Functions
export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    console.error("Error signing in with Google:", error);
    throw error;
  }
};

export const signUpWithEmail = async (email: string, password: string) => {
  try {
    const result = await createUserWithEmailAndPassword(auth, email, password);
    return result.user;
  } catch (error: any) {
    console.error("Error signing up with email:", error);
    throw error;
  }
};

export const signInWithEmailAndPassword = async (email: string, password: string) => {
  try {
    const result = await signInWithEmail(auth, email, password);
    return result.user;
  } catch (error: any) {
    console.error("Error signing in with email:", error);
    throw error;
  }
};

export const signOut = async () => {
  try {
    await firebaseSignOut(auth);
    // Clear any local user data
    if (typeof window !== 'undefined') {
      localStorage.removeItem('nyay_current_user');
    }
  } catch (error) {
    console.error("Error signing out:", error);
    throw error;
  }
};

// Current user helper 
export const getCurrentUser = () => {
  return new Promise<User | null>((resolve, reject) => {
    const unsubscribe = onAuthStateChanged(
      auth,
      (user) => {
        unsubscribe();
        resolve(user);
      },
      reject
    );
  });
};

export { auth, app }; 
"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Check, Upload } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function UploadPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [content, setContent] = useState("")
  const [documentTitle, setDocumentTitle] = useState("")
  const [documentType, setDocumentType] = useState("legal_document")
  const [source, setSource] = useState("")
  const [isUploading, setIsUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<{success: boolean; message: string} | null>(null)

  // Redirect if not logged in
  useEffect(() => {
    if (user === null) {
      router.push("/login?redirect=/upload")
    }
  }, [user, router])

  if (!user) {
    return null // Don't render anything while redirecting
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!content.trim() || !documentTitle.trim()) {
      setUploadStatus({
        success: false,
        message: "Please provide both document content and title"
      })
      return
    }

    setIsUploading(true)
    setUploadStatus(null)

    try {
      // Make POST request to the backend
      const response = await fetch('http://localhost:8001/add-document', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: content,
          metadata: {
            title: documentTitle,
            type: documentType,
            source: source,
            uploaded_by: user.name || user.email || "anonymous",
            upload_date: new Date().toISOString()
          }
        }),
      })
      
      if (!response.ok) {
        throw new Error(`Backend error: ${response.status}`)
      }
      
      const data = await response.json()
      
      // Show success message
      setUploadStatus({
        success: true,
        message: "Document successfully added to the knowledge base"
      })
      
      // Reset form
      setContent("")
      setDocumentTitle("")
      setSource("")
      
    } catch (error) {
      console.error('Error uploading document:', error)
      setUploadStatus({
        success: false,
        message: "Failed to upload document. Please try again."
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="container max-w-3xl py-8">
      <h1 className="text-3xl font-bold mb-6">Upload Document to Knowledge Base</h1>
      <p className="text-muted-foreground mb-8">
        Add documents to the AI's knowledge base to improve its responses. Documents added 
        here will be used as reference material when answering related questions.
      </p>

      {uploadStatus && (
        <Alert 
          className={`mb-6 ${uploadStatus.success ? 'border-green-500 text-green-700' : 'border-red-500 text-red-700'}`}
        >
          <div className="flex items-center gap-2">
            {uploadStatus.success ? <Check className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
            <AlertTitle>{uploadStatus.success ? "Success" : "Error"}</AlertTitle>
          </div>
          <AlertDescription>{uploadStatus.message}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Document Information</CardTitle>
          <CardDescription>
            Enter the content and metadata for the document you want to add
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Document Title</Label>
              <Input 
                id="title" 
                placeholder="Enter document title" 
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="documentType">Document Type</Label>
              <Select 
                value={documentType} 
                onValueChange={setDocumentType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="legal_document">Legal Document</SelectItem>
                  <SelectItem value="case_law">Case Law</SelectItem>
                  <SelectItem value="statute">Statute</SelectItem>
                  <SelectItem value="legal_article">Legal Article</SelectItem>
                  <SelectItem value="legal_guide">Legal Guide</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="source">Source (optional)</Label>
              <Input 
                id="source" 
                placeholder="Enter source of the document" 
                value={source}
                onChange={(e) => setSource(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="content">Document Content</Label>
              <Textarea 
                id="content" 
                placeholder="Paste or type the document content here..." 
                className="h-64"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                required
              />
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => router.back()}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isUploading}
              className="flex items-center gap-2"
            >
              {isUploading ? "Uploading..." : (
                <>
                  <Upload className="h-4 w-4" />
                  Upload Document
                </>
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
} 
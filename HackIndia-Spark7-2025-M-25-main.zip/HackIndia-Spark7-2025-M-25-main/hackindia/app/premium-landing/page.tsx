"use client"

import Hero from "@/components/landing/Hero";
import Partners from "@/components/landing/Partners";
import Features from "@/components/landing/Features";
import UserCategories from "@/components/landing/UserCategories";
import AIPowered from "@/components/landing/AIPowered";
import DocumentAnalysis from "@/components/landing/DocumentAnalysis";
import MultiPlatform from "@/components/landing/MultiPlatform";
import CTASection from "@/components/landing/CTASection";

export default function PremiumLanding() {
  return (
    <div className="flex flex-col w-full">
      <Hero />
      <Partners />
      <Features />
      <UserCategories />
      <AIPowered />
      <DocumentAnalysis />
      <MultiPlatform />
      <CTASection />
    </div>
  );
} 
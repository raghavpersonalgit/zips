"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Send, User, Bot, Mic, StopCircle, PaperclipIcon, Plus, ChevronDown, ChevronUp, Lock } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import Link from "next/link"
import { useRouter } from "next/navigation"

type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
  sources?: Array<{content: string, metadata: any}>
}

type Conversation = {
  id: string
  title: string
  messages: Message[]
  createdAt: Date
}

export default function ChatPage() {
  const [input, setInput] = useState("")
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null)
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [showSidebar, setShowSidebar] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const isMobile = useMobile()
  const { user } = useAuth()
  const router = useRouter()

  // Initialize with a welcome message
  useEffect(() => {
    if (conversations.length === 0) {
      const newConversation: Conversation = {
        id: "welcome",
        title: "New Conversation",
        messages: [
          {
            id: "welcome",
            content:
              "Hello! I'm Nyay AI, your legal assistant. How can I help you today?",
            role: "assistant",
            timestamp: new Date(),
          },
        ],
        createdAt: new Date(),
      }
      setConversations([newConversation])
      setActiveConversation(newConversation)
    }
  }, [conversations])

  // Toggle sidebar on mobile/desktop change
  useEffect(() => {
    setShowSidebar(!isMobile)
  }, [isMobile])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [activeConversation?.messages])

  // Redirect if not logged in
  useEffect(() => {
    if (user === null) {
      router.push("/login?redirect=/chat")
    }
  }, [user, router])

  if (!user) {
    return null // Don't render anything while redirecting
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || !activeConversation) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: "user",
      timestamp: new Date(),
    }

    const updatedConversation = {
      ...activeConversation,
      messages: [...activeConversation.messages, userMessage],
    }

    setActiveConversation(updatedConversation)
    setConversations(conversations.map((conv) => (conv.id === activeConversation.id ? updatedConversation : conv)))
    setInput("")
    setIsLoading(true)

    // Update conversation title if it's the first user message
    if (activeConversation.messages.length === 1) {
      const newTitle = input.length > 30 ? `${input.substring(0, 30)}...` : input
      const updatedWithTitle = {
        ...updatedConversation,
        title: newTitle,
      }
      setActiveConversation(updatedWithTitle)
      setConversations(conversations.map((conv) => (conv.id === activeConversation.id ? updatedWithTitle : conv)))
    }

    try {
      // Get username from Firebase Auth
      let username = 'anonymous_user';
      if (user) {
        if (user.name) username = user.name;
        else if (user.email) username = user.email.split('@')[0];
      }
      
      // Make POST request to the FastAPI backend
      const response = await fetch('http://localhost:8003/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: input,
          username: username,
        }),
      })
      
      if (!response.ok) {
        console.error(`Backend error: ${response.status}`)
        throw new Error(`Backend error: ${response.status}`)
      }
      
      try {
        const data = await response.json()
        
        // Create AI message from the backend response
        const aiMessage: Message = {
          id: Date.now().toString(),
          content: data.response,
          role: "assistant",
          timestamp: new Date(),
          sources: data.sources || []
        }

        const finalConversation = {
          ...updatedConversation,
          messages: [...updatedConversation.messages, aiMessage],
        }

        setActiveConversation(finalConversation)
        setConversations(conversations.map((conv) => (conv.id === activeConversation.id ? finalConversation : conv)))
      } catch (jsonError) {
        console.error('Error parsing JSON response:', jsonError)
        throw new Error('Invalid response from server')
      }
    } catch (error) {
      console.error('Error fetching response from backend:', error)
      
      // Fallback response in case of error
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "I'm sorry, there was an error processing your request. Please try again later.",
        role: "assistant",
        timestamp: new Date(),
      }
      
      const finalConversation = {
        ...updatedConversation,
        messages: [...updatedConversation.messages, errorMessage],
      }
      
      setActiveConversation(finalConversation)
      setConversations(conversations.map((conv) => (conv.id === activeConversation.id ? finalConversation : conv)))
    } finally {
      setIsLoading(false)
    }
  }

  const createNewConversation = () => {
    const newConversation: Conversation = {
      id: Date.now().toString(),
      title: "New Conversation",
      messages: [
        {
          id: "welcome",
          content:
            "Hello! I'm Nyay AI, your legal assistant. How can I help you today?",
          role: "assistant",
          timestamp: new Date(),
        },
      ],
      createdAt: new Date(),
    }
    setConversations([newConversation, ...conversations])
    setActiveConversation(newConversation)
  }

  const deleteConversation = (id: string) => {
    const updatedConversations = conversations.filter((conv) => conv.id !== id)
    setConversations(updatedConversations)

    if (activeConversation?.id === id) {
      setActiveConversation(updatedConversations[0] || null)
    }
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    // Here you would implement actual speech recognition
    if (!isRecording) {
      // Start recording
      console.log("Started recording")
    } else {
      // Stop recording and process
      console.log("Stopped recording")
      setTimeout(() => {
        setInput("I have a legal issue with my landlord.")
      }, 1000)
    }
  }

  // Premium features that require subscription
  const isPremiumFeature = (featureName: string) => {
    return user.role === "lawyer" && user.subscriptionTier !== "premium"
  }

  // Function to render each message with sources if available
  const renderMessage = (message: Message) => {
    return (
      <div
        className={`flex items-start gap-3 max-w-[80%] ${
          message.role === "user" ? "flex-row-reverse" : "flex-row"
        }`}
      >
        <div
          className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${
            message.role === "user" ? "bg-saffron-500" : "bg-india-green-500"
          }`}
        >
          {message.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
        </div>
        <div
          className={`p-3 rounded-lg ${
            message.role === "user"
              ? "bg-saffron-500 text-white rounded-br-none"
              : "bg-muted rounded-bl-none"
          }`}
        >
          <p className="whitespace-pre-wrap">{message.content}</p>
          
          {/* Display sources when available */}
          {message.sources && message.sources.length > 0 && (
            <div className="mt-3 pt-2 border-t border-gray-200 dark:border-gray-700">
              <details className="text-xs">
                <summary className="cursor-pointer font-medium">
                  Sources ({message.sources.length})
                </summary>
                <div className="mt-2 space-y-2">
                  {message.sources.map((source, idx) => (
                    <div key={idx} className="p-2 bg-gray-100 dark:bg-gray-800 rounded text-foreground">
                      {source.metadata?.title && (
                        <div className="font-medium mb-1">{source.metadata.title}</div>
                      )}
                      <div className="opacity-90">{source.content.substring(0, 120)}...</div>
                    </div>
                  ))}
                </div>
              </details>
            </div>
          )}
          
          <p className="text-xs opacity-70 mt-1">
            {message.timestamp.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Sidebar */}
      {showSidebar && (
        <div className="w-64 h-full border-r flex flex-col bg-muted/30">
          <div className="p-4 border-b">
            <Button
              onClick={createNewConversation}
              variant="secondary"
              className="w-full flex items-center justify-center gap-2"
            >
              <Plus className="h-4 w-4" />
              New Chat
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {conversations.map((conversation) => (
              <motion.div
                key={conversation.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className={`flex items-center gap-2 p-3 rounded-md hover:bg-muted transition-colors cursor-pointer ${
                  activeConversation?.id === conversation.id ? "bg-muted" : ""
                }`}
                onClick={() => setActiveConversation(conversation)}
              >
                <div className="flex-1 overflow-hidden">
                  <div className="font-medium truncate">{conversation.title}</div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(conversation.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 opacity-0 group-hover:opacity-100"
                  onClick={(e) => {
                    e.stopPropagation()
                    deleteConversation(conversation.id)
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M3 6h18"></path>
                    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                  </svg>
                </Button>
              </motion.div>
            ))}
          </div>

          {/* User info in sidebar */}
          <div className="p-4 border-t">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-saffron-500 flex items-center justify-center text-white">
                {user && user.name ? user.name.substring(0, 1).toUpperCase() : "U"}
              </div>
              <div className="flex-1 overflow-hidden">
                <div className="font-medium truncate">{user && user.name ? user.name : "User"}</div>
                <div className="flex items-center gap-1">
                  <span
                    className={`text-xs px-1.5 py-0.5 rounded-full ${
                      user && user.subscriptionTier === "premium"
                        ? "bg-india-green-100 text-india-green-800 dark:bg-india-green-900 dark:text-india-green-200"
                        : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
                    }`}
                  >
                    {user && user.subscriptionTier === "premium" ? "Premium" : "Free"}
                  </span>
                  <span className="text-xs text-muted-foreground truncate">{user && user.role}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full">
        {/* Chat Header */}
        <div className="border-b p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isMobile && (
              <Button variant="ghost" size="icon" onClick={() => setShowSidebar(!showSidebar)}>
                {showSidebar ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </Button>
            )}
            <h2 className="font-semibold">{activeConversation?.title || "New Conversation"}</h2>
          </div>
          {user.role === "lawyer" && user.subscriptionTier !== "premium" && (
            <Button asChild variant="outline" size="sm" className="text-xs">
              <Link href="/pricing">
                <Lock className="h-3 w-3 mr-1" />
                Upgrade to Premium
              </Link>
            </Button>
          )}
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto bg-background">
          <div className="flex flex-col p-4 gap-6">
            <AnimatePresence>
              {activeConversation?.messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {renderMessage(message)}
                </motion.div>
              ))}

              {/* Loading/Typing Indicator */}
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-india-green-500 flex items-center justify-center text-white">
                      <Bot className="h-4 w-4" />
                    </div>
                    <div className="p-3 rounded-lg bg-muted rounded-bl-none">
                      <div className="flex space-x-2">
                        <div className="w-2 h-2 rounded-full bg-foreground/30 animate-bounce" />
                        <div
                          className="w-2 h-2 rounded-full bg-foreground/30 animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        />
                        <div
                          className="w-2 h-2 rounded-full bg-foreground/30 animate-bounce"
                          style={{ animationDelay: "0.4s" }}
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Premium Features Bar (only for lawyers) */}
        {user.role === "lawyer" && (
          <div className="border-t p-2 flex items-center gap-2 overflow-x-auto">
            <TooltipProvider>
              {[
                { name: "Case Analysis", icon: "📊", premium: true },
                { name: "Document Draft", icon: "📝", premium: true },
                { name: "Legal Research", icon: "🔍", premium: true },
                { name: "Citation Check", icon: "📚", premium: true },
              ].map((feature) => (
                <Tooltip key={feature.name}>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className={`text-xs whitespace-nowrap ${
                        feature.premium && user.subscriptionTier !== "premium" ? "opacity-50 cursor-not-allowed" : ""
                      }`}
                      disabled={feature.premium && user.subscriptionTier !== "premium"}
                    >
                      {feature.premium && user.subscriptionTier !== "premium" && <Lock className="h-3 w-3 mr-1" />}
                      {feature.icon} {feature.name}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    {feature.premium && user.subscriptionTier !== "premium"
                      ? `Upgrade to Premium to use ${feature.name}`
                      : feature.name}
                  </TooltipContent>
                </Tooltip>
              ))}
            </TooltipProvider>
          </div>
        )}

        {/* Input Area */}
        <div className="border-t p-4 bg-background">
          <form onSubmit={handleSubmit} className="relative">
            <div className="flex items-center border rounded-xl overflow-hidden shadow-sm focus-within:ring-2 focus-within:ring-saffron-500">
              <button
                type="button"
                className="p-2 text-muted-foreground hover:text-foreground"
                onClick={toggleRecording}
              >
                {isRecording ? <StopCircle className="h-5 w-5 text-red-500" /> : <Mic className="h-5 w-5" />}
              </button>

              <Textarea
                placeholder="Type your message here..."
                className="flex-1 py-3 px-2 bg-transparent focus:outline-none resize-none min-h-[60px] max-h-[200px]"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSubmit(e)
                  }
                }}
              />

              <button type="button" className="p-2 text-muted-foreground hover:text-foreground">
                <PaperclipIcon className="h-5 w-5" />
              </button>

              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="p-2 m-1 rounded-lg bg-india-green-500 text-white hover:bg-india-green-600 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>

            <div className="text-xs text-center mt-2 text-muted-foreground">
              Nyay AI may produce inaccurate information about people, places, or facts.
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

import type { Metadata } from "next"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Lawyer Assistant - Nyay AI",
  description: "Professional legal assistance for lawyers and legal professionals",
}

export default function LawyerLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <section className={`${inter.className}`}>
      {children}
    </section>
  )
} 
"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"

export default function CitizenLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // Redirect if not authenticated or not a citizen
    if (!isLoading && (!user || user.role !== "citizen")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  // Show loading spinner while checking auth
  if (isLoading || !user || user.role !== "citizen") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  // If authenticated and is a citizen, show the content
  return <>{children}</>
} 
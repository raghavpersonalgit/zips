"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { motion } from "framer-motion"
import { HelpCircle, FileText, MessageSquare, Shield, Users, Lightbulb } from "lucide-react"

export default function CitizensPage() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-8rem)]">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-muted/50 to-background">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col justify-center space-y-4"
            >
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Legal Help Made Simple</h1>
                <p className="text-xl text-muted-foreground">
                  Access easy-to-understand legal assistance
                </p>
              </div>
              <div className="space-y-2">
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Nyay AI helps you understand your rights, navigate legal processes, and find solutions to common legal
                  problems.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg">
                  <Link href="/chat">Ask a Legal Question</Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="/citizens/resources">Browse Resources</Link>
                </Button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mx-auto w-full max-w-[500px] rounded-xl overflow-hidden shadow-xl"
            >
              <div className="w-full aspect-video bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-950 dark:to-pink-950 flex items-center justify-center">
                <div className="p-8 bg-background/80 backdrop-blur-sm rounded-lg shadow-lg max-w-[80%]">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <MessageSquare className="h-4 w-4 text-primary" />
                      </div>
                      <div className="h-4 w-3/4 bg-muted rounded"></div>
                    </div>
                    <div className="h-4 w-full bg-muted rounded"></div>
                    <div className="h-4 w-5/6 bg-muted rounded"></div>
                    <div className="h-4 w-2/3 bg-muted rounded"></div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How Nyay AI Helps You</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Simple steps to get the legal help you need
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:gap-12 mt-12">
            {[
              {
                icon: <MessageSquare className="h-6 w-6 text-primary" />,
                title: "Ask Your Question",
                description: "Type your legal question",
              },
              {
                icon: <HelpCircle className="h-6 w-6 text-primary" />,
                title: "Get Clear Answers",
                description: "Receive easy-to-understand explanations of your legal rights and options",
              },
              {
                icon: <FileText className="h-6 w-6 text-primary" />,
                title: "Access Resources",
                description: "Find forms, guides, and next steps to help resolve your issue",
              },
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex flex-col items-center space-y-4 text-center"
              >
                <div className="rounded-full p-3 bg-primary/10">{step.icon}</div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Common Legal Topics */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Common Legal Topics</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Explore information on these frequently asked legal areas
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 mt-12">
            {[
              {
                title: "Family Law",
                description: "Marriage, divorce, child custody, and maintenance",
                icon: <Users className="h-6 w-6" />,
              },
              {
                title: "Property Rights",
                description: "Land ownership, inheritance, and property disputes",
                icon: <Shield className="h-6 w-6" />,
              },
              {
                title: "Consumer Protection",
                description: "Product defects, service issues, and refund rights",
                icon: <Shield className="h-6 w-6" />,
              },
              {
                title: "Employment Law",
                description: "Workplace rights, wages, and discrimination",
                icon: <FileText className="h-6 w-6" />,
              },
              {
                title: "Criminal Law",
                description: "Understanding charges, rights, and procedures",
                icon: <Shield className="h-6 w-6" />,
              },
              {
                title: "Government Benefits",
                description: "Eligibility and application for government schemes",
                icon: <Lightbulb className="h-6 w-6" />,
              },
            ].map((topic, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                viewport={{ once: true }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <div className="rounded-full w-10 h-10 bg-primary/10 flex items-center justify-center mb-2">
                      {topic.icon}
                    </div>
                    <CardTitle>{topic.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{topic.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/topics/${topic.title.toLowerCase().replace(/\s+/g, "-")}`}>Learn More</Link>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Success Stories</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                How Nyay AI has helped people across Bharat
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:gap-12 mt-12">
            {[
              {
                quote:
                  "I was able to understand my rights as a tenant. The guidance helped me resolve a dispute with my landlord without going to court.",
                name: "Ramesh Kumar",
                location: "Lucknow, UP",
              },
              {
                quote:
                  "As a small business owner, I needed help with a contract issue. Nyay AI explained everything and helped me draft a response.",
                name: "Gurpreet Kaur",
                location: "Amritsar, Punjab",
              },
            ].map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl">
                      <span className="text-4xl text-primary">"</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{testimonial.quote}</p>
                  </CardContent>
                  <CardFooter>
                    <div>
                      <p className="font-semibold">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                    </div>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="space-y-2"
            >
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Have a legal question?</h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Get answers on your schedule
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <Button asChild size="lg">
                <Link href="/chat">Ask Nyay AI Now</Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}

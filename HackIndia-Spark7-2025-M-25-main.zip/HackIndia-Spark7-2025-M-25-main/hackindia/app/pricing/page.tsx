"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, X } from "lucide-react"
import { motion } from "framer-motion"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/components/ui/use-toast"

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")
  const { user, updateSubscription } = useAuth()
  const { toast } = useToast()

  const handleSubscribe = (tier: "free" | "premium") => {
    if (!user) {
      // Redirect to login if not logged in
      window.location.href = "/login?redirect=/pricing"
      return
    }

    if (tier === "premium") {
      // In a real app, this would redirect to a payment page
      // For this demo, we'll just update the subscription
      updateSubscription("premium")
      toast({
        title: "Subscription Updated",
        description: "You are now a premium subscriber!",
        duration: 5000,
      })
    } else {
      updateSubscription("free")
      toast({
        title: "Subscription Updated",
        description: "You are now on the free plan.",
        duration: 5000,
      })
    }
  }

  const features = {
    free: [
      { name: "Basic legal assistance", included: true },
      { name: "Multilingual support", included: true },
      { name: "Access to common legal information", included: true },
      { name: "Basic document templates", included: true },
      { name: "Advanced case analysis", included: false },
      { name: "Legal research tools", included: false },
      { name: "Analytics dashboard", included: false },
      { name: "Priority support", included: false },
    ],
    premium: [
      { name: "Basic legal assistance", included: true },
      { name: "Multilingual support", included: true },
      { name: "Access to common legal information", included: true },
      { name: "Basic document templates", included: true },
      { name: "Advanced case analysis", included: true },
      { name: "Legal research tools", included: true },
      { name: "Analytics dashboard", included: true },
      { name: "Priority support", included: true },
    ],
  }

  return (
    <div className="container py-12 md:py-24">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Simple, Transparent Pricing</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Choose the plan that's right for you, whether you're a citizen seeking basic legal help or a lawyer needing
          advanced tools.
        </p>

        <div className="flex items-center justify-center mt-8 space-x-4">
          <Button
            variant={billingCycle === "monthly" ? "default" : "outline"}
            onClick={() => setBillingCycle("monthly")}
            className={billingCycle === "monthly" ? "bg-saffron-500 hover:bg-saffron-600" : ""}
          >
            Monthly
          </Button>
          <Button
            variant={billingCycle === "yearly" ? "default" : "outline"}
            onClick={() => setBillingCycle("yearly")}
            className={billingCycle === "yearly" ? "bg-saffron-500 hover:bg-saffron-600" : ""}
          >
            Yearly
            <span className="ml-2 text-xs bg-india-green-500 text-white px-2 py-0.5 rounded-full">Save 20%</span>
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {/* Free Plan */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card className="border-2 border-muted h-full flex flex-col">
            <CardHeader>
              <CardTitle className="text-2xl">Citizen Plan</CardTitle>
              <CardDescription>For individuals seeking basic legal assistance</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">₹0</span>
                <span className="text-muted-foreground">/month</span>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-3">
                {features.free.map((feature, i) => (
                  <li key={i} className="flex items-center">
                    {feature.included ? (
                      <Check className="h-5 w-5 text-india-green-500 mr-2" />
                    ) : (
                      <X className="h-5 w-5 text-muted-foreground mr-2" />
                    )}
                    <span className={feature.included ? "" : "text-muted-foreground"}>{feature.name}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                onClick={() => handleSubscribe("free")}
                className="w-full bg-muted hover:bg-muted/80"
                variant="outline"
              >
                {user?.subscriptionTier === "free" ? "Current Plan" : "Get Started"}
              </Button>
            </CardFooter>
          </Card>
        </motion.div>

        {/* Premium Plan */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="border-2 border-saffron-500 h-full flex flex-col relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-saffron-500 text-white px-3 py-1 text-sm font-medium">
              Popular
            </div>
            <CardHeader>
              <CardTitle className="text-2xl">Lawyer Plan</CardTitle>
              <CardDescription>For legal professionals needing advanced tools</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">₹{billingCycle === "monthly" ? "1,999" : "19,190"}</span>
                <span className="text-muted-foreground">/{billingCycle === "monthly" ? "month" : "year"}</span>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-3">
                {features.premium.map((feature, i) => (
                  <li key={i} className="flex items-center">
                    <Check className="h-5 w-5 text-india-green-500 mr-2" />
                    <span>{feature.name}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button onClick={() => handleSubscribe("premium")} className="w-full bg-saffron-500 hover:bg-saffron-600">
                {user?.subscriptionTier === "premium" ? "Current Plan" : "Subscribe Now"}
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
        <div className="max-w-3xl mx-auto space-y-6 text-left">
          <div>
            <h3 className="font-bold">What's included in the Citizen Plan?</h3>
            <p className="text-muted-foreground">
              The Citizen Plan provides basic legal assistance in multiple languages, access to common legal
              information, and basic document templates.
            </p>
          </div>
          <div>
            <h3 className="font-bold">What additional features do I get with the Lawyer Plan?</h3>
            <p className="text-muted-foreground">
              The Lawyer Plan includes everything in the Citizen Plan plus advanced case analysis, legal research tools,
              an analytics dashboard, and priority support.
            </p>
          </div>
          <div>
            <h3 className="font-bold">Can I upgrade or downgrade my plan?</h3>
            <p className="text-muted-foreground">
              Yes, you can upgrade or downgrade your plan at any time. If you downgrade, you'll continue to have access
              to premium features until the end of your current billing cycle.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

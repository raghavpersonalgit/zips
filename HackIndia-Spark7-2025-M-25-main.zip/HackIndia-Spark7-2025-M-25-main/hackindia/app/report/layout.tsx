import type { Metadata } from "next"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Legal Templates - Nyay AI",
  description: "Choose from ready-made legal templates and generate documents instantly",
}

export default function ReportLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <section className={`${inter.className}`}>
      {children}
    </section>
  )
} 
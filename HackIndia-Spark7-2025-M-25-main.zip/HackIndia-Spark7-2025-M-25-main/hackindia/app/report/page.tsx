"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Check, FileText, Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Share2 } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// List of Indian states for dropdown
const indianStates = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Delhi",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Lakshadweep",
  "Puducherry",
  "Ladakh",
  "Jammu and Kashmir"
];

// Groq API details
const GROQ_API_KEY = "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";
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";

// Template categories and types
const legalTemplates = [
  { id: "sales", name: "Sales Documents and Forms", icon: <FileText className="h-5 w-5" /> },
  { id: "policy", name: "Policy and Compliance Documents", icon: <FileText className="h-5 w-5" /> },
  { id: "letters", name: "Letters and Notices Templates", icon: <FileText className="h-5 w-5" /> },
  { id: "web", name: "Web & Technology Agreements", icon: <FileText className="h-5 w-5" /> },
  { id: "proposal", name: "Proposal Templates", icon: <FileText className="h-5 w-5" /> },
  { id: "financial", name: "Financial Agreements", icon: <FileText className="h-5 w-5" /> },
  { id: "family", name: "Family Law", icon: <FileText className="h-5 w-5" /> },
  { id: "employment", name: "Employment Legal Templates", icon: <FileText className="h-5 w-5" /> },
  { id: "realestate", name: "Real Estate", icon: <FileText className="h-5 w-5" /> },
  { id: "b2b", name: "B2B Legal Documents", icon: <FileText className="h-5 w-5" /> },
  { id: "business", name: "Business Document", icon: <FileText className="h-5 w-5" /> },
  { id: "lastwill", name: "Last Will and Testament", icon: <FileText className="h-5 w-5" /> },
  { id: "billsale", name: "Bill of Sale", icon: <FileText className="h-5 w-5" /> },
  { id: "poa", name: "Power of Attorney (POA)", icon: <FileText className="h-5 w-5" /> },
  { id: "eviction", name: "Eviction Notice", icon: <FileText className="h-5 w-5" /> },
  { id: "nda", name: "NDA (Non-Disclosure Agreements)", icon: <FileText className="h-5 w-5" /> },
  { id: "lease", name: "Lease Agreement", icon: <FileText className="h-5 w-5" /> },
]

// Quick template options
const quickTemplates = [
  "Rental agreement",
  "Eviction notice",
  "NDA",
  "Last will and testament"
]

export default function ReportPage() {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [title, setTitle] = useState("")
  const [recipient, setRecipient] = useState("")
  const [description, setDescription] = useState("")
  const [state, setState] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0])
  
  // New state variables for PDF handling
  const [pdfUrl, setPdfUrl] = useState<string | null>(null)
  const [isPdfPreviewOpen, setIsPdfPreviewOpen] = useState(false)
  const [generatedContent, setGeneratedContent] = useState<any>(null)

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId)
    setIsDialogOpen(true)
  }

  const handleQuickTemplateSelect = (template: string) => {
    setSelectedTemplate(template.toLowerCase().replace(/\s+/g, "-"))
    setIsDialogOpen(true)
  }

  const handleGenerateReport = async () => {
    if (!title || !description || !state) {
      setError("Please fill in all required fields")
      return
    }
    
    setIsLoading(true)
    setError("")
    
    try {
      // Generate content using Groq API
      const content = await generateLegalContentWithGroq(
        selectedTemplate || '', 
        title, 
        recipient, 
        description,
        state,
        date
      )
      
      // Store the generated content for later use
      setGeneratedContent(content)
      
      // Generate PDF but don't download it automatically
      const pdfBlobUrl = await generatePDFBlob(content, title, state)
      setPdfUrl(pdfBlobUrl)
      
      // Show the success dialog with preview and sharing options
      setIsLoading(false)
      setIsPdfPreviewOpen(true)
    } catch (err: any) {
      setError(err.message || "An error occurred while generating the report")
      setIsLoading(false)
    }
  }

  // Generate legal content using Groq API
  const generateLegalContentWithGroq = async (
    templateType: string, 
    title: string, 
    recipient: string, 
    description: string,
    state: string,
    date: string
  ) => {
    const templateName = legalTemplates.find(t => t.id === templateType)?.name || 
                        templateType.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')
    
    try {
      const prompt = `
        Create a formal Indian legal document for a "${templateName}".
        
        Title: ${title}
        ${recipient ? `Recipient: ${recipient}` : ''}
        State: ${state}
        Date: ${date}
        
        Document Description: ${description}
        
        Generate a comprehensive legal document with proper Indian legal formatting and terminology.
        The document should use language and structure that would be acceptable in an Indian court of law.
        Please include all necessary sections, clauses, and legal language appropriate for this type of document.
        
        Format the content in a formal, professional manner suitable for legal documents in India.
        Include appropriate legal references to Indian laws and statutes where relevant.
        
        IMPORTANT FORMATTING INSTRUCTIONS:
        1. The document should open with "IN THE HIGH COURT OF ${state.toUpperCase()}" without any asterisks.
        2. Section titles should be bold or in all caps without asterisks.
        3. Use formal legal language appropriate for Indian courts.
        4. Include proper paragraph formatting with clear section divisions.
        5. Do not use asterisks (**) for emphasis.
      `;
      
      const response = await fetch(GROQ_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${GROQ_API_KEY}`
        },
        body: JSON.stringify({
          model: "llama3-70b-8192",
          messages: [
            {
              role: "system",
              content: "You are an expert legal document drafting assistant specializing in Indian law and legal formats. Create formal legal documents following Indian judicial standards and formatting. Do NOT use asterisks for emphasis."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.2,
          max_tokens: 4096
        })
      });
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      let generatedContent = data.choices[0].message.content;
      
      // Remove any remaining double asterisks if they exist
      generatedContent = generatedContent.replace(/\*\*/g, '');
      
      return {
        title,
        recipient,
        templateName,
        state,
        date: new Date(date).toLocaleDateString('en-IN', {
          day: '2-digit',
          month: 'long',
          year: 'numeric'
        }),
        content: generatedContent
      };
    } catch (error) {
      console.error("Error calling Groq API:", error);
      
      // Fallback content in case of API error
      return {
        title,
        recipient,
        templateName,
        state,
        date: new Date(date).toLocaleDateString('en-IN', {
          day: '2-digit',
          month: 'long',
          year: 'numeric'
        }),
        content: `IN THE HIGH COURT OF ${state.toUpperCase()}

${templateName.toUpperCase()}

THIS AGREEMENT is made on this ${new Date(date).getDate()}th day of ${new Date(date).toLocaleString('en-IN', { month: 'long' })}, ${new Date(date).getFullYear()}

BETWEEN

${recipient || "[RECIPIENT NAME]"} (hereinafter referred to as "the Recipient" or "Party of the Second Part")

AND

[YOUR COMPANY NAME] (hereinafter referred to as "the Service Provider" or "Party of the First Part")

WHEREAS the Service Provider has agreed to provide certain services as detailed in this agreement;

AND WHEREAS the Recipient has agreed to accept such services on the terms and conditions hereinafter appearing;

NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:

1. SCOPE OF SERVICES
   The Service Provider agrees to provide the following services to the Recipient: ${description}

2. TERM
   This Agreement shall commence on the date of execution and shall continue until terminated by either party as per the terms of this Agreement.

3. CONSIDERATION
   In consideration of the services provided, the Recipient shall pay to the Service Provider such fees as agreed between the parties.

4. GOVERNING LAW
   This Agreement shall be governed by and construed in accordance with the laws of India.

5. JURISDICTION
   Any dispute arising out of or in connection with this Agreement shall be subject to the exclusive jurisdiction of the courts in ${state}.

IN WITNESS WHEREOF, the parties hereto have executed this Agreement on the day and year first above written.

For [YOUR COMPANY NAME]                      For ${recipient || "[RECIPIENT]"}

____________________                         ____________________
Authorized Signatory                         Authorized Signatory`
      };
    }
  }

  const generatePDFBlob = async (content: any, documentTitle: string, state: string): Promise<string> => {
    try {
      // Dynamically import jsPDF only on the client side
      const { jsPDF } = await import("jspdf");
      // Import required add-ons for tables
      await import("jspdf-autotable");
      
      // Create a new PDF document
      const doc = new jsPDF();
      
      // Set standard font to Times Roman (closest to Times New Roman that's built in)
      doc.setFont("times", "roman");
      
      // Add Indian emblem placeholder
      try {
        // In a real implementation, you would use a base64 encoded image of the Indian emblem
        // For now, we'll create a simple text-based emblem placeholder
        doc.setFontSize(14);
        doc.setFont("times", "bold");
        doc.text("Government of India", doc.internal.pageSize.getWidth() / 2, 15, { align: "center" });
        
        // Draw a simple emblem-like shape
        const centerX = doc.internal.pageSize.getWidth() / 2;
        doc.setDrawColor(0, 0, 128); // Navy blue
        doc.setLineWidth(0.5);
        doc.circle(centerX, 25, 8, 'S');
        doc.line(centerX - 10, 25, centerX + 10, 25);
        doc.line(centerX, 15, centerX, 35);
      } catch (imgError) {
        console.error("Error adding emblem:", imgError);
      }
      
      // Add header
      doc.setFontSize(14);
      doc.setFont("times", "bold");
      doc.text(`IN THE HIGH COURT OF ${state.toUpperCase()}`, doc.internal.pageSize.getWidth() / 2, 45, { align: "center" });
      
      // Add title
      doc.setFontSize(16);
      doc.text(content.title.toUpperCase(), doc.internal.pageSize.getWidth() / 2, 55, { align: "center" });
      
      // Add date
      doc.setFontSize(11);
      doc.setFont("times", "normal");
      doc.text(`Date: ${content.date}`, 150, 65, { align: "right" });
      
      // Add recipient if available
      let yPos = 75;
      if (content.recipient) {
        doc.text(`To: ${content.recipient}`, 20, yPos);
        yPos += 10;
      }
      
      // Add divider
      doc.setDrawColor(0);
      doc.setLineWidth(0.5);
      doc.line(20, yPos, 190, yPos);
      yPos += 10;
      
      // Add content with word wrapping
      doc.setFontSize(11);
      const splitText = doc.splitTextToSize(content.content, 170);
      doc.text(splitText, 20, yPos);
      
      // Add footer - fixed for types
      const totalPages = (doc as any).internal.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.text(
          `Generated using Nyay AI - Page ${i} of ${totalPages}`,
          doc.internal.pageSize.getWidth() / 2,
          doc.internal.pageSize.getHeight() - 10,
          { align: "center" }
        );
      }
      
      // Return blob URL instead of saving
      const blob = doc.output('blob');
      return URL.createObjectURL(blob);
    } catch (error) {
      console.error("PDF generation error:", error);
      throw new Error("Error generating PDF. Please try again.");
    }
  }

  // Function to download the PDF
  const downloadPDF = () => {
    if (!pdfUrl || !generatedContent) return;
    
    const a = document.createElement('a');
    a.href = pdfUrl;
    a.download = `${title.replace(/\s+/g, "-")}-${state.replace(/\s+/g, "-")}-legal-document.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
  
  // Function to share the PDF
  const sharePDF = async () => {
    if (!pdfUrl) return;
    
    // Check if Web Share API is supported
    if (navigator.share) {
      try {
        // For file sharing support (may not work in all browsers)
        if (navigator.canShare && navigator.canShare({ files: [new File([], 'test.txt')] })) {
          // Convert blob URL to file
          const response = await fetch(pdfUrl);
          const blob = await response.blob();
          const file = new File([blob], `${title}-legal-document.pdf`, { type: 'application/pdf' });
          
          await navigator.share({
            title: `${title} - Legal Document`,
            text: 'Check out this legal document I created with Nyay AI',
            files: [file]
          });
        } else {
          // Fallback to sharing without files
          await navigator.share({
            title: `${title} - Legal Document`,
            text: 'Check out this legal document I created with Nyay AI',
            url: window.location.href // Would be better with a shareable URL
          });
        }
      } catch (error) {
        console.error('Error sharing document:', error);
      }
    } else {
      // Fallback: copy link or show sharing options
      alert('Sharing is not supported on this device. Please download the document and share it manually.');
    }
  }

  const resetForm = () => {
    setTitle("")
    setRecipient("")
    setDescription("")
    setState("")
    setPdfUrl(null)
    setGeneratedContent(null)
  }

  // Filter templates based on search term
  const filteredTemplates = legalTemplates.filter(template => 
    template.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="container py-10">
      <div className="text-center mb-10">
        <h1 className="text-5xl font-bold mb-4">Ready-made free legal templates</h1>
        <p className="text-xl mb-8">Simplify your work! Choose from 12 categories of documents designed for various legal tasks.</p>
        
        <div className="flex items-center justify-between max-w-3xl mx-auto">
          <div className="flex items-center bg-background border rounded-md px-3 py-2 w-full">
            <Search className="h-4 w-4 text-muted-foreground mr-2" />
            <Input 
              className="border-0 focus-visible:ring-0 p-0 text-sm"
              placeholder="Quick document search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {searchTerm === "" && (
          <div className="flex flex-wrap gap-2 justify-center mt-4">
            {quickTemplates.map((template, index) => (
              <Button 
                key={index} 
                variant="link" 
                className="text-blue-500"
                onClick={() => handleQuickTemplateSelect(template)}
              >
                {template}
              </Button>
            ))}
          </div>
        )}
      </div>
      
      <div className="mt-8">
        <h2 className="text-lg font-medium mb-4">All categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTemplates.map(template => (
            <div 
              key={template.id}
              onClick={() => handleTemplateSelect(template.id)}
              className="flex items-center gap-3 p-4 border rounded-lg cursor-pointer hover:bg-accent/50 transition-colors"
            >
              <div className="flex-shrink-0 text-muted-foreground">
                {template.icon}
              </div>
              <span className="font-medium">{template.name}</span>
            </div>
          ))}
        </div>
      </div>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {selectedTemplate && 
                legalTemplates.find(t => t.id === selectedTemplate)?.name || 
                selectedTemplate?.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
            </DialogTitle>
            <DialogDescription>
              Fill in the details below to generate your legal document
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                placeholder="Document title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="recipient">To (Optional)</Label>
              <Input
                id="recipient"
                placeholder="Recipient name"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="state">State</Label>
              <Select value={state} onValueChange={(value) => setState(value)} required>
                <SelectTrigger id="state">
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent>
                  {indianStates.map((state) => (
                    <SelectItem key={state} value={state}>
                      {state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Briefly describe what you need in this document..."
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
              <p className="text-sm text-muted-foreground">
                The AI will generate the document content based on this description
              </p>
            </div>
            
            {error && (
              <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm">
                {error}
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button onClick={() => setIsDialogOpen(false)} variant="outline">
              Cancel
            </Button>
            <Button 
              onClick={handleGenerateReport} 
              disabled={isLoading}
              className="bg-india-green-500 hover:bg-india-green-600"
            >
              {isLoading ? (
                <>
                  <span className="mr-2">Generating...</span>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                </>
              ) : (
                "Generate Document"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isPdfPreviewOpen} onOpenChange={setIsPdfPreviewOpen}>
        <AlertDialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
          <AlertDialogHeader>
            <AlertDialogTitle>Document Generated Successfully</AlertDialogTitle>
            <AlertDialogDescription>
              Your legal document has been created. You can preview, download, or share it using the options below.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="flex-1 overflow-hidden my-4">
            {pdfUrl && (
              <iframe 
                src={pdfUrl} 
                className="w-full h-[60vh] border rounded"
                title="PDF Preview"
              />
            )}
          </div>
          
          <AlertDialogFooter className="flex flex-col sm:flex-row gap-2">
            <div className="flex-1 flex gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex gap-2 items-center">
                    <Share2 className="h-4 w-4" />
                    Share
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={sharePDF}>
                    Native Share
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => {
                    if (!pdfUrl) return;
                    window.open(`https://wa.me/?text=Check out this legal document: ${encodeURIComponent(window.location.href)}`, '_blank');
                  }}>
                    WhatsApp
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => {
                    if (!pdfUrl) return;
                    window.open(`mailto:?subject=${encodeURIComponent(`Legal Document: ${title}`)}&body=${encodeURIComponent(`I've created a legal document using Nyay AI. Please check it out.`)}`, '_blank');
                  }}>
                    Email
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button variant="secondary" onClick={downloadPDF}>
                Download PDF
              </Button>
            </div>
            
            <Button onClick={() => {
              setIsPdfPreviewOpen(false);
              setIsDialogOpen(false);
              resetForm();
            }}>
              Close
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
} 
"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"
import { useAuth } from "@/components/auth-provider"

export default function CompleteSignupPage() {
  const [role, setRole] = useState<"citizen" | "lawyer">("citizen")
  const [isLoading, setIsLoading] = useState(false)
  const searchParams = useSearchParams()
  const router = useRouter()
  const { user, setUserType } = useAuth()
  
  // Pre-select role if provided in URL
  useEffect(() => {
    const roleParam = searchParams.get("role")
    if (roleParam === "citizen" || roleParam === "lawyer") {
      setRole(roleParam)
    }
  }, [searchParams])
  
  // Redirect to chat if user is not logged in
  useEffect(() => {
    if (!user) {
      router.push("/login")
    }
  }, [user, router])
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    try {
      // Save the user role
      setUserType(role)
      
      // Redirect to chat page
      router.push("/chat")
    } catch (error) {
      console.error("Error saving user role:", error)
    } finally {
      setIsLoading(false)
    }
  }
  
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-8rem)]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }
  
  return (
    <div className="container flex items-center justify-center min-h-[calc(100vh-8rem)]">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">Complete Your Profile</CardTitle>
          <CardDescription>Select your role to continue</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>I am a</Label>
              <RadioGroup
                value={role}
                onValueChange={(value) => setRole(value as "citizen" | "lawyer")}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="citizen" id="citizen" />
                  <Label htmlFor="citizen">Citizen</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="lawyer" id="lawyer" />
                  <Label htmlFor="lawyer">Lawyer</Label>
                </div>
              </RadioGroup>
            </div>
            <Button type="submit" className="w-full bg-saffron-500 hover:bg-saffron-600" disabled={isLoading}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Continue
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
} 
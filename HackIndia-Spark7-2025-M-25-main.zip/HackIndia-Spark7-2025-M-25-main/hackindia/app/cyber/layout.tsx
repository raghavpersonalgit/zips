import type { Metadata } from "next"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Cyber Law Assistant - Nyay AI",
  description: "Expert assistance with cyber laws and digital regulations in India",
}

export default function CyberLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <section className={`${inter.className}`}>
      {children}
    </section>
  )
} 
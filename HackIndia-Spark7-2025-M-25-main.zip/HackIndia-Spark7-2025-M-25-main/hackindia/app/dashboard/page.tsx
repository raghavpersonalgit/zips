"use client"

import { useEffect } from "react"
import { useAuth } from "@/components/auth-provider"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Lock, BarChart2, FileText, Clock, Users, ArrowUpRight } from "lucide-react"

export default function DashboardPage() {
  const { user } = useAuth()
  const router = useRouter()

  // Redirect if not logged in or not a lawyer
  useEffect(() => {
    if (user === null) {
      router.push("/login?redirect=/dashboard")
    } else if (user?.role !== "lawyer") {
      router.push("/")
    }
  }, [user, router])

  if (!user || user.role !== "lawyer") {
    return null // Don't render anything while redirecting
  }

  const isPremium = user.subscriptionTier === "premium"

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Lawyer Dashboard</h1>
          <p className="text-muted-foreground">Track your performance, manage cases, and access premium features</p>
        </div>
        {!isPremium && (
          <Button asChild className="bg-saffron-500 hover:bg-saffron-600">
            <Link href="/pricing">
              <Lock className="h-4 w-4 mr-2" />
              Upgrade to Premium
            </Link>
          </Button>
        )}
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics" disabled={!isPremium}>
            {!isPremium && <Lock className="h-3 w-3 mr-1" />}
            Analytics
          </TabsTrigger>
          <TabsTrigger value="cases" disabled={!isPremium}>
            {!isPremium && <Lock className="h-3 w-3 mr-1" />}
            Cases
          </TabsTrigger>
          <TabsTrigger value="documents" disabled={!isPremium}>
            {!isPremium && <Lock className="h-3 w-3 mr-1" />}
            Documents
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Conversations</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">+2 from last week</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Usage Time</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4.2 hrs</div>
                <p className="text-xs text-muted-foreground">+0.8 hrs from last week</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Documents Generated</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">7</div>
                <p className="text-xs text-muted-foreground">+3 from last week</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Subscription Status</CardTitle>
                <BarChart2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {isPremium ? (
                    <span className="text-india-green-500">Premium</span>
                  ) : (
                    <span className="text-muted-foreground">Free</span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {isPremium
                    ? `Expires: ${new Date(user.subscriptionEndsAt || "").toLocaleDateString()}`
                    : "Limited features"}
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-2">
            <Card className={!isPremium ? "opacity-75" : ""}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  Recent Activity
                  {!isPremium && <Lock className="h-4 w-4 ml-2" />}
                </CardTitle>
                <CardDescription>Your recent interactions with Nyay AI</CardDescription>
              </CardHeader>
              <CardContent>
                {isPremium ? (
                  <div className="space-y-4">
                    {[
                      {
                        title: "Property Dispute Analysis",
                        date: "2 hours ago",
                        type: "Case Analysis",
                      },
                      {
                        title: "Legal Notice Draft",
                        date: "Yesterday",
                        type: "Document",
                      },
                      {
                        title: "Contract Review",
                        date: "3 days ago",
                        type: "Legal Research",
                      },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{item.title}</p>
                          <p className="text-sm text-muted-foreground">{item.date}</p>
                        </div>
                        <span className="text-xs bg-muted px-2 py-1 rounded-full">{item.type}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-40 text-center">
                    <Lock className="h-8 w-8 mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">Upgrade to Premium to access activity tracking</p>
                    <Button asChild className="mt-4 bg-saffron-500 hover:bg-saffron-600">
                      <Link href="/pricing">Upgrade Now</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className={!isPremium ? "opacity-75" : ""}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  Performance Metrics
                  {!isPremium && <Lock className="h-4 w-4 ml-2" />}
                </CardTitle>
                <CardDescription>Track your efficiency and outcomes</CardDescription>
              </CardHeader>
              <CardContent>
                {isPremium ? (
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Case Resolution Rate</span>
                        <span className="text-sm font-medium">78%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-india-green-500 h-2 rounded-full" style={{ width: "78%" }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Client Satisfaction</span>
                        <span className="text-sm font-medium">92%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-saffron-500 h-2 rounded-full" style={{ width: "92%" }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Time Saved</span>
                        <span className="text-sm font-medium">12.5 hrs/week</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: "65%" }}></div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-40 text-center">
                    <Lock className="h-8 w-8 mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">Upgrade to Premium to access performance metrics</p>
                    <Button asChild className="mt-4 bg-saffron-500 hover:bg-saffron-600">
                      <Link href="/pricing">Upgrade Now</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common tasks to get you started</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <Button asChild variant="outline" className="h-auto flex flex-col items-center justify-center p-4">
                    <Link href="/chat">
                      <Users className="h-6 w-6 mb-2" />
                      <span className="text-sm font-medium">Start New Chat</span>
                      <span className="text-xs text-muted-foreground mt-1">Ask legal questions</span>
                    </Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className={`h-auto flex flex-col items-center justify-center p-4 ${
                      !isPremium ? "opacity-75 cursor-not-allowed" : ""
                    }`}
                    disabled={!isPremium}
                  >
                    <Link href={isPremium ? "/dashboard/documents" : "/pricing"}>
                      {!isPremium && <Lock className="absolute top-2 right-2 h-3 w-3" />}
                      <FileText className="h-6 w-6 mb-2" />
                      <span className="text-sm font-medium">Draft Document</span>
                      <span className="text-xs text-muted-foreground mt-1">Create legal documents</span>
                    </Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className={`h-auto flex flex-col items-center justify-center p-4 ${
                      !isPremium ? "opacity-75 cursor-not-allowed" : ""
                    }`}
                    disabled={!isPremium}
                  >
                    <Link href={isPremium ? "/dashboard/analytics" : "/pricing"}>
                      {!isPremium && <Lock className="absolute top-2 right-2 h-3 w-3" />}
                      <BarChart2 className="h-6 w-6 mb-2" />
                      <span className="text-sm font-medium">View Analytics</span>
                      <span className="text-xs text-muted-foreground mt-1">Track your performance</span>
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          {isPremium ? (
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Usage Analytics</CardTitle>
                  <CardDescription>Your AI usage patterns over time</CardDescription>
                </CardHeader>
                <CardContent className="h-80 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <BarChart2 className="h-16 w-16 mx-auto mb-4" />
                    <p>Analytics visualization would appear here</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Case Outcomes</CardTitle>
                  <CardDescription>Track the results of your legal cases</CardDescription>
                </CardHeader>
                <CardContent className="h-80 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <BarChart2 className="h-16 w-16 mx-auto mb-4" />
                    <p>Case outcome visualization would appear here</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Lock className="h-16 w-16 mb-4 text-muted-foreground" />
              <h2 className="text-2xl font-bold mb-2">Premium Feature</h2>
              <p className="text-muted-foreground max-w-md mb-6">
                Upgrade to Premium to access detailed analytics about your performance, case outcomes, and usage
                patterns.
              </p>
              <Button asChild className="bg-saffron-500 hover:bg-saffron-600">
                <Link href="/pricing">Upgrade to Premium</Link>
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="cases">
          {isPremium ? (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Active Cases</CardTitle>
                  <CardDescription>Cases you're currently working on</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        title: "Singh vs. Mehta Property Dispute",
                        client: "Rajesh Singh",
                        status: "In Progress",
                        lastUpdated: "2 days ago",
                      },
                      {
                        title: "Sharma Family Inheritance Case",
                        client: "Priya Sharma",
                        status: "Pending Court Date",
                        lastUpdated: "1 week ago",
                      },
                      {
                        title: "Kumar Commercial Contract Dispute",
                        client: "Vikram Kumar",
                        status: "Document Preparation",
                        lastUpdated: "3 days ago",
                      },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">{item.title}</p>
                          <p className="text-sm text-muted-foreground">Client: {item.client}</p>
                          <p className="text-xs text-muted-foreground">Last updated: {item.lastUpdated}</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <span
                            className={`text-xs px-2 py-1 rounded-full ${
                              item.status === "In Progress"
                                ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                                : item.status === "Pending Court Date"
                                  ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                                  : "bg-india-green-100 text-india-green-800 dark:bg-india-green-900 dark:text-india-green-200"
                            }`}
                          >
                            {item.status}
                          </span>
                          <Button variant="ghost" size="sm">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Lock className="h-16 w-16 mb-4 text-muted-foreground" />
              <h2 className="text-2xl font-bold mb-2">Premium Feature</h2>
              <p className="text-muted-foreground max-w-md mb-6">
                Upgrade to Premium to track and manage your legal cases with our advanced case management system.
              </p>
              <Button asChild className="bg-saffron-500 hover:bg-saffron-600">
                <Link href="/pricing">Upgrade to Premium</Link>
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="documents">
          {isPremium ? (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Documents</CardTitle>
                  <CardDescription>Documents you've created or edited recently</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        title: "Legal Notice - Property Encroachment",
                        type: "Notice",
                        created: "May 15, 2023",
                        status: "Final",
                      },
                      {
                        title: "Rental Agreement - Commercial Property",
                        type: "Agreement",
                        created: "May 10, 2023",
                        status: "Draft",
                      },
                      {
                        title: "Will and Testament - Sharma Family",
                        type: "Will",
                        created: "May 5, 2023",
                        status: "Review",
                      },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <FileText className="h-8 w-8 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{item.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {item.type} • Created on {item.created}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-xs px-2 py-1 rounded-full ${
                              item.status === "Final"
                                ? "bg-india-green-100 text-india-green-800 dark:bg-india-green-900 dark:text-india-green-200"
                                : item.status === "Draft"
                                  ? "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
                                  : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                            }`}
                          >
                            {item.status}
                          </span>
                          <Button variant="ghost" size="sm">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Lock className="h-16 w-16 mb-4 text-muted-foreground" />
              <h2 className="text-2xl font-bold mb-2">Premium Feature</h2>
              <p className="text-muted-foreground max-w-md mb-6">
                Upgrade to Premium to create, edit, and manage legal documents with our advanced document generation
                tools.
              </p>
              <Button asChild className="bg-saffron-500 hover:bg-saffron-600">
                <Link href="/pricing">Upgrade to Premium</Link>
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

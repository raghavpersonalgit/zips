import Graph from "../components/Graph/Graphs";

function Analytics() {
  return (
    <div>
      <Graph />
    </div>
  );
}

export default Analytics;

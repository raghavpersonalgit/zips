# HackIndia-Spark-7-2025-She-Codes

🚀 Project Name: Call-It-Done
Your Autonomous Meeting Companion

Call-It-Done is a smart productivity tool designed to transform how teams capture, summarize, and organize meeting information. It functions both as a Chrome extension and a web-based application, offering seamless integration with Azure Whisper, GPT-4, and Notion.

🔹 Key Features:
📌 Real-time Transcription
A lightweight Chrome extension captures live audio during virtual meetings and transcribes it instantly using Azure’s Whisper model. Stay focused on the conversation while Call-It-Done handles the notes.

📂 Post-Meeting Processing
Upload recorded meeting links through our web portal. The backend processes the audio using Whisper for transcription and GPT-4 for intelligent summarization.

📝 Auto-Generated Meeting Notes
Key takeaways, action items, and summaries are automatically created and pushed to your Notion workspace, organizing them under relevant projects or dates.

🔗 Dual Interface Support

Extension: Best for live, in-the-moment meetings.

Website: Ideal for reviewing past sessions or processing pre-recorded meetings.

🌐 Tech Stack:
Frontend: HTML, CSS, JavaScript (Extension), React (Website)

Backend: Python Flask

AI Services: Azure Whisper for transcription, OpenAI GPT-4 for summarization

Integrations: Notion API for note storage and organization

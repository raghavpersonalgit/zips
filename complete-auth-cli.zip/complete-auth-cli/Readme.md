# Complete Auth System

> A simple, ready-to-use authentication system for full-stack developers.

## Overview

`complete-auth-system` saves you time by providing a pre-built authentication system with all essential features. No need to rebuild authentication from scratch for every project - just install, configure, and go!

## Key Features

* ✓ User Registration
* ✓ Email Verification
* ✓ 2-Factor Authentication
* ✓ Login with OTP
* ✓ Login with Password
* ✓ Login with OTP and Password Both
* ✓ Forget / Reset Password
* ✓ Profile Management
* ✓ Token Management
* And Many more...
* You Just need to change some things according to your need and you are good to go.

## Installation

```bash
# Basic installation
npx complete-auth-system <folder_name>

# Custom frontend/backend folder names
npx complete-auth-system <folder_name> --frontend <frontend_folder_name> --backend <backend_folder_name>
```

## Setup

### Backend Configuration
Create a `.env` file in the backend directory with the following variables:

```
PORT=7000
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/complete-auth
FRONTEND_URL=http://localhost:5173

EMAIL_USER="your-email@gmail.com"
EMAIL_PASS="your-app-password"  # Generate app password from your email provider

NODE_ENV=development
JWT_SECRET=your_jwt_secret
JWT_REFRESH_SECRET=your_jwt_refresh_secret

CLOUDINARY_NAME=your_cloudinary_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

### Frontend Configuration
Create a `.env` file in the frontend directory:

```
VITE_API_BACKEND_API_URL=http://localhost:7000/api/v1
NODE_ENV=development
```

## Project Structure

### Frontend
```
src/
  ├── components/    # UI components
  ├── pages/         # Application pages
  ├── redux/         # State management
  ├── lib/           # Utility libraries
  ├── assets/        # Static assets
  └── App.jsx        # Main application component
```

### Backend
```
├── config/          # Configuration files
├── controllers/     # Request handlers
├── middleware/      # Custom middleware
├── models/          # Database models
├── routes/          # API routes
├── services/        # Business logic
├── utils/           # Helper functions
├── uploads/         # File uploads directory
└── server.js        # Entry point
```

## Getting Started

1. Install the package using the npx command
2. Configure environment variables
3. Start the backend: `cd <folder_name>/backend && npm run dev`
4. Start the frontend: `cd <folder_name>/frontend && npm run dev`

## Note

This package provides a complete authentication system that you can customize to suit your project needs. The email verification feature requires you to generate an app password from your email provider.
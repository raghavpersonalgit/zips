1. check for credit limit (assign low limit in db and try to create an interview with high value) ----> fixed

2. check all input validation ----> done

3. if fo to the interview meeting page camera starts and if moving to any other route
the camera is not stopping, it should stop only after browser load its stopping

4. use own google credential in clerk to remove the development mode

5. fix the fetch all interviews currently its fetching all interviews it should fetch interviews for that candidate only -----> done

6. fix date and time in interview cards  ----> done

7. Before the call start there should be a loading screen in the videoCall UI.  ----> done

8. if the user wants to end the call and press the end-call button show the modal
do you realy want to end the call like that

9. Line 662 in call component an error is showing in browser console
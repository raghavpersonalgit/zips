import LandingPage from "./_components/(home)/LandingPage";


export default function page() {
  return (
    <>
      {/* <Home /> */}
      <LandingPage />
      {/* <HeroSection /> */}
    </>
  );
}

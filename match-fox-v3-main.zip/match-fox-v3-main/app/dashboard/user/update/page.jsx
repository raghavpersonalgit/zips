import UserProfileUpdate from "./_components/UserProfileUpdate";

export default function page() {

  return (
    <>
        <UserProfileUpdate />
    </>
  );
}

import AllResume from "./_components/AllResume";
import CreateResume from "./_components/CreateResume";


export default async function AIResume() {
  
  return (
    <>
      <AllResume />
    </>
  );
};



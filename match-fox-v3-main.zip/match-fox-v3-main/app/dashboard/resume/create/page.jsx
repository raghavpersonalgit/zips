import CreateResume from "../_components/CreateResume";


export default async function page() {
  
  return (
    <>
      <CreateResume />
    </>
  );
};



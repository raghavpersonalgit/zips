import JobForm from "../_components/JobForm";


export default async function page() {
  
  return (
    <>
      <JobForm />

    </>
  );
};



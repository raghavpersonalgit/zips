
import JobComponent from "./_components/JobComponent";


export default async function page() {
  
  return (
    <>
      {/* <JobForm /> */}
      <JobComponent />

    </>
  );
};



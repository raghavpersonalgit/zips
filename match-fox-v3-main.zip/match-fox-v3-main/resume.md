based on the above job description can you rephrase resume, make it ATS friendly\,
Rephrase my resume based on the given job description above to make it more ATS-friendly?

Please use this framework: "Action Verb + Noun + Metric + [Strategy Optional] + Outcome = 1 bulleted achievement."

Please rewrite the resume in a more engaging and natural way. Use nondramatic language.

Rewrite my resume to align with the following job description

Proofread my resume and suggest improvements for clarity and readability, check any spelling mistake or grammer mistake

Analyze my resume for ATS optimization based on this job description.

Add keywords in the resume based on the job description to imporve ATS score.

add 10 additional new keywords to my resume to improve ATS compatibility with the given job description

Use a more personalized resume voice to make my content sound less robotic.

Rewrite my resume to remove overly formal or repetitive AI-generated phrasing while keeping it professional. 

Adjust my resume tone to sound more natural and engaging, avoiding stiff or overly polished language. 

Edit my resume to include a mix of sentence structures that feel more natural and human-written.

import React from "react";

const Page = () => {
  return <div>Admin Dashboard</div>;
};
export default Page;

import os
import re
import uuid
import hashlib
import pdfplumber
from tqdm import tqdm

# Pinecone + LangChain
from pinecone import Pinecone, ServerlessSpec
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Pinecone as LangchainPinecone

# ✅ Your legal document name ↔ filename ↔ link mapping
legal_documents = {
    "The Code of Civil Procedure, 1908": "https://www.indiacode.nic.in/bitstream/123456789/11087/1/the_code_of_civil_procedure%2C_1908.pdf",
    "The Code of Criminal Procedure, 1973": "https://www.indiacode.nic.in/bitstream/123456789/15272/1/the_code_of_criminal_procedure%2C_1973.pdf",
    "The Constitution of India": "https://www.indiacode.nic.in/bitstream/123456789/15240/1/constitution_of_india.pdf",
    "The Indian Contract Act, 1872": "https://www.indiacode.nic.in/bitstream/123456789/2187/2/A187209.pdf",
    "The Indian Evidence Act, 1872": "https://www.indiacode.nic.in/bitstream/123456789/15351/1/iea_1872.pdf",
    "The Indian Penal Code, 1860": "https://www.indiacode.nic.in/bitstream/123456789/4219/1/THE-INDIAN-PENAL-CODE-1860.pdf",
    "The Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021": "https://upload.indiacode.nic.in/showfile?actid=AC_CEN_45_76_00001_200021_1517807324077&filename=information_technology_%28intermediary_guidelines_and_digital_media_ethics_code%29_rules%2C_2021_%28updated_06.04.2023%29-.pdf&type=rule",
    "The Limitation Act, 1963": "https://www.indiacode.nic.in/bitstream/123456789/1565/5/A1963-36.pdf",
    "The Registration Act, 1908": "https://www.indiacode.nic.in/bitstream/123456789/15937/1/the_registration_act%2C1908.pdf",
    "The Specific Relief Act, 1963": "https://www.indiacode.nic.in/bitstream/123456789/1583/7/A1963-47.pdf"
}

# Normalize document filenames to match against actual files
def find_doc_metadata(filename):
    for title, url in legal_documents.items():
        expected_name = os.path.basename(url).replace('%2C', ',').replace('%28', '(').replace('%29', ')').replace('%20', ' ').lower()
        if expected_name in filename.lower():
            return title, url
    return "Unknown Document", "N/A"

# ✅ Pinecone init
api_key = "pcsk_2w3P93_4JfzzGbQqQjn1SjxDrwMN7f9jvNvaSLhfdmqTg4PrAf5kRZyj12e6sLS5E7Xmim"
pc = Pinecone(api_key=api_key)
index_name = "law"

if index_name not in pc.list_indexes().names():
    pc.create_index(
        name=index_name,
        dimension=1024,
        metric="cosine",
        spec=ServerlessSpec(cloud="aws", region="us-east-1")
    )
index = pc.Index(index_name)

# ✅ Embedding model
embedder = HuggingFaceEmbeddings(model_name="intfloat/e5-large-v2")

# ✅ Sentence hashing
def hash_sentence(text):
    return hashlib.sha256(text.strip().lower().encode()).hexdigest()

# ✅ PDF parsing
def parse_pdf_to_sentences(file_path, max_len=400):
    sentences = []
    with pdfplumber.open(file_path) as pdf:
        buffer = ""
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            for line in lines:
                buffer += " " + line
                if re.search(r'[.:!?]$', line) or len(buffer) > max_len:
                    sentences.append(buffer.strip())
                    buffer = ""
        if buffer:
            sentences.append(buffer.strip())
    return sentences

# ✅ Pinecone upload
def add_sentences_to_pinecone(sentences, filename):
    seen = set()
    vectors = []

    doc_title, doc_url = find_doc_metadata(filename)

    for sentence in tqdm(sentences, desc=f"Indexing {filename}"):
        norm = sentence.strip().lower()
        if norm in seen:
            continue
        seen.add(norm)

        input_text = f"passage: {sentence}"
        vector = embedder.embed_query(input_text)

        vectors.append({
            "id": hash_sentence(sentence),
            "values": vector,
            "metadata": {
                "text": sentence,
                "source_file": filename,
                "document_title": doc_title,
                "document_url": doc_url
            }
        })

    if vectors:
        index.upsert(vectors=vectors)

# ✅ Ingest all PDFs
current_dir = os.getcwd()
pdf_files = [f for f in os.listdir(current_dir) if f.endswith(".pdf")]

for pdf_file in pdf_files:
    print(f"\n📄 Parsing: {pdf_file}")
    full_path = os.path.join(current_dir, pdf_file)
    sentences = parse_pdf_to_sentences(full_path)
    for i, sentence in enumerate(sentences, 1):
        print(f"{i:03d}: {sentence}")
    add_sentences_to_pinecone(sentences, pdf_file)

# ✅ Build retriever
retriever = LangchainPinecone(index, embedder.embed_query, "text").as_retriever()
import os
import pdfplumber
import re

def parse_pdf_to_sentences(file_path):
    sentences = []
    with pdfplumber.open(file_path) as pdf:
        buffer = ""
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue

            # Split into raw lines
            lines = [line.strip() for line in text.split('\n') if line.strip()]

            for line in lines:
                buffer += " " + line  # Append line to buffer
                if re.search(r'[.:!?]$', line):  # If line ends with sentence-ending punctuation
                    sentences.append(buffer.strip())
                    buffer = ""

        if buffer:  # Add remaining buffer if any
            sentences.append(buffer.strip())

    return sentences

# Get current directory
current_dir = os.getcwd()

# Find all PDF files
pdf_files = [f for f in os.listdir(current_dir) if f.endswith('.pdf')]

# Parse and print each file nicely
for pdf_file in pdf_files:
    full_path = os.path.join(current_dir, pdf_file)
    print(f"\n====== 📄 Parsing: {pdf_file} ======")
    sentences = parse_pdf_to_sentences(full_path)
    for i, sentence in enumerate(sentences, start=1):
        print(f"{i:03d}: {sentence}")

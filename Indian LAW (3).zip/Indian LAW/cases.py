import os
import re
import uuid
import hashlib
import pdfplumber
from tqdm import tqdm
from pinecone import Pinecone, ServerlessSpec
from sentence_transformers import SentenceTransformer

# ✅ Load SentenceTransformer directly
model = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")

# ✅ Pinecone init
api_key = "pcsk_41NHNX_7N6eG4cSMHvDrnQNHw5HPJDzZ6i1VddMGR4QGzYopF6LX8ZvjpEZntfUx6A8zLb"
pc = Pinecone(api_key=api_key)
index_name = "langchain"

if index_name not in pc.list_indexes().names():
    pc.create_index(
        name=index_name,
        dimension=768,  # ⚠️ Dimension for all-mpnet-base-v2
        metric="cosine",
        spec=ServerlessSpec(cloud="aws", region="us-east-1")
    )
index = pc.Index(index_name)

# ✅ Sentence hashing
def hash_sentence(text):
    return hashlib.sha256(text.strip().lower().encode()).hexdigest()

# ✅ PDF parsing
def parse_pdf_to_sentences(file_path, max_len=400):
    sentences = []
    with pdfplumber.open(file_path) as pdf:
        buffer = ""
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            for line in lines:
                buffer += " " + line
                if re.search(r'[.:!?]$', line) or len(buffer) > max_len:
                    sentences.append(buffer.strip())
                    buffer = ""
        if buffer:
            sentences.append(buffer.strip())
    return sentences

# ✅ Pinecone upload
def add_sentences_to_pinecone(sentences, filename):
    seen = set()
    vectors = []

    for sentence in tqdm(sentences, desc=f"Indexing {filename}"):
        norm = sentence.strip().lower()
        if norm in seen:
            continue
        seen.add(norm)

        # No "passage:" prefix needed — model is not instruction-tuned
        vector = model.encode(sentence).tolist()

        vectors.append({
            "id": hash_sentence(sentence),
            "values": vector,
            "metadata": {
                "text": sentence,
                "source_file": filename,
            }
        })

    if vectors:
        index.upsert(vectors=vectors)

# ✅ Ingest all PDFs
current_dir = r"C:\Users\aeest\Downloads\archive\pdfs"
pdf_files = [f for f in os.listdir(current_dir) if f.endswith(".pdf")]

for pdf_file in pdf_files:
    print(f"\n📄 Parsing: {pdf_file}")
    full_path = os.path.join(current_dir, pdf_file)
    sentences = parse_pdf_to_sentences(full_path)
    for i, sentence in enumerate(sentences, 1):
        print(f"{i:03d}: {sentence}")
    add_sentences_to_pinecone(sentences, pdf_file)

from notion_client import Client

# Your Notion integration token
notion = Client(auth="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")

# The ID of your existing Notion page ("law")
parent_page_id = "1e650090-8b5e-80d4-94f7-ef5eb6280ae4"

# Create a sub-page inside "law"
new_page = notion.pages.create(
    parent={"type": "page_id", "page_id": parent_page_id},
    properties={
        "title": [
            {
                "type": "text",
                "text": {"content": "📄 Subpage from Python"}
            }
        ]
    },
    children=[
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {"content": "This is a new page created from Python"}
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "And it's living inside your 'law' Notion page."
                        }
                    }
                ]
            }
        }
    ]
)

print("✅ New subpage created!")
print("Page ID:", new_page["id"])
print("URL: https://www.notion.so/" + new_page["id"].replace("-", ""))

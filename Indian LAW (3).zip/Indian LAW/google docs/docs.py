import os
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Scopes for Google Docs and Drive API
SCOPES = [
    'https://www.googleapis.com/auth/documents',
    'https://www.googleapis.com/auth/drive.file'
]

def get_credentials():
    creds = None

    # Get absolute paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    creds_path = os.path.join(script_dir, 'credentials.json')
    token_path = os.path.join(script_dir, 'token.pkl')

    if os.path.exists(token_path):
        with open(token_path, 'rb') as token_file:
            creds = pickle.load(token_file)
    else:
        # Use Desktop OAuth flow with a fixed safe port
        flow = InstalledAppFlow.from_client_secrets_file(creds_path, SCOPES)
        creds = flow.run_local_server(port=8080)
        with open(token_path, 'wb') as token_file:
            pickle.dump(creds, token_file)

    return creds

def main():
    creds = get_credentials()

    # Initialize Docs and Drive clients
    docs_service = build('docs', 'v1', credentials=creds)
    drive_service = build('drive', 'v3', credentials=creds)

    # Create a new Google Doc
    doc = docs_service.documents().create(body={'title': 'OAuth Desktop Doc'}).execute()
    doc_id = doc.get('documentId')
    print(f'Document created: https://docs.google.com/document/d/{doc_id}/edit')

    # Write content into the document
    docs_service.documents().batchUpdate(
        documentId=doc_id,
        body={
            'requests': [{
                'insertText': {
                    'location': {'index': 1},
                    'text': 'This is a test document created using Desktop App OAuth.\n'
                }
            }]
        }
    ).execute()

    # Make it viewable by anyone
    drive_service.permissions().create(
        fileId=doc_id,
        body={'type': 'anyone', 'role': 'reader'},
        fields='id'
    ).execute()

    print("✅ The document is public and contains text.")

if __name__ == '__main__':
    main()

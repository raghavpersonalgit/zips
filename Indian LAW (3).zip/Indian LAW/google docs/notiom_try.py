from notion_client import Client

# Use your new integration token
notion = Client(auth="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")

# Parent page ID: from your shared Notion page (law)
parent_page_id = "1e650090-8b5e-80d4-94f7-ef5eb6280ae4"

# Create a new sub-page inside "law"
new_page = notion.pages.create(
    parent={"type": "page_id", "page_id": parent_page_id},
    properties={
        "title": [
            {
                "type": "text",
                "text": {"content": "📄 Subpage from Python"}
            }
        ]
    },
    children=[
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {"content": "✅ Success!"}
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "This page was created inside the 'law' page using Python and Notion's API."
                        }
                    }
                ]
            }
        }
    ]
)

# Output the Notion page URL
page_id = new_page["id"]
print("✅ Page created successfully!")
print("Page URL: https://www.notion.so/" + page_id.replace("-", ""))

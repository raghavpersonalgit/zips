from langchain_community.tools.tavily_search import TavilySearchResults

# Initialize the Tavily search tool with your API key and max_results
tavily_search = TavilySearchResults(max_results=3, tavily_api_key="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")

# Example query
search_docs = tavily_search.invoke("""post related to el classico score latest""")

# View raw results
for i, doc in enumerate(search_docs, 1):
    print(f"Result {i}:")
    print(doc)
    print()

import csv
import time
import json
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.edge.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

# Twitter login credentials
twitter_username = "hsrreroll1008@gmail.com"
twitter_password = "madhav123"

def login_to_twitter(driver):
    try:
        driver.get("https://x.com/login")
        username_field = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.NAME, "text"))
        )
        username_field.send_keys(twitter_username)
        next_button = driver.find_element(By.XPATH, "//span[contains(text(), 'Next')]")
        next_button.click()
        password_field = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.NAME, "password"))
        )
        password_field.send_keys(twitter_password)
        login_button = driver.find_element(By.XPATH, "//span[contains(text(), 'Log in')]")
        login_button.click()
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '[data-testid="tweet"]'))
        )
        print("Login successful!")
    except Exception as e:
        print(f"Login failed: {str(e)}")
        raise

def scrape_twitter_search(query: str, csv_filename: str = "tweets.csv"):
    options = Options()
    driver = webdriver.Edge(options=options)
    try:
        login_to_twitter(driver)
        driver.get(f"https://x.com/search?q={query}&src=typed_query")
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '[data-testid="tweet"]'))
        )
        
        # Open CSV file for writing
        with open(csv_filename, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(["Handle", "Content", "Timestamp", "URL"])
            
            print("Scraping tweets. Press Ctrl+C to stop.")
            tweet_texts = set()
            
            while True:
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(2)
                new_tweets = driver.find_elements(By.CSS_SELECTOR, '[data-testid="tweet"]')
                
                for tweet in new_tweets:
                    try:
                        user_element = tweet.find_element(By.CSS_SELECTOR, '[data-testid="User-Name"]')
                        handle = user_element.find_elements(By.TAG_NAME, 'span')[-1].text
                        content = tweet.find_element(By.CSS_SELECTOR, '[data-testid="tweetText"]').text
                        timestamp = tweet.find_element(By.TAG_NAME, 'time').get_attribute('datetime')
                        if content not in tweet_texts:
                            writer.writerow([handle, content, timestamp, driver.current_url])
                            tweet_texts.add(content)
                            file.flush()
                    except Exception as e:
                        continue
    except KeyboardInterrupt:
        print("Scraping stopped by user.")
    finally:
        driver.quit()

if __name__ == "__main__":
    query = "Artificial Intelligence"
    scrape_twitter_search(query)
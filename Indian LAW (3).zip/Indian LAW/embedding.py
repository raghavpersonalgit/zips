import pdfplumber
from transformers import AutoTokenizer
from sentence_transformers import SentenceTransformer
from typing import List

# Config
MAX_TOKENS = 2000
EMBEDDING_MODEL = "sentence-transformers/all-mpnet-base-v2"

# Load tokenizer and model
tokenizer = AutoTokenizer.from_pretrained(EMBEDDING_MODEL)
model = SentenceTransformer(EMBEDDING_MODEL)

# Step 1: Extract paragraphs from PDF
def extract_paragraphs(pdf_path: str) -> List[str]:
    paragraphs = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                # Split based on paragraph logic (double newline or block)
                raw_paragraphs = text.split('\n\n')
                for para in raw_paragraphs:
                    cleaned = para.strip().replace('\n', ' ')
                    if cleaned:
                        paragraphs.append(cleaned)
    return paragraphs

# Step 2: Split paragraphs into chunks under 2000 tokens
def chunk_paragraph(para: str, max_tokens=MAX_TOKENS) -> List[str]:
    tokens = tokenizer.encode(para)
    if len(tokens) <= max_tokens:
        return [para]

    chunks = []
    start = 0
    while start < len(tokens):
        end = min(start + max_tokens, len(tokens))
        chunk_tokens = tokens[start:end]
        decoded = tokenizer.decode(chunk_tokens, skip_special_tokens=True)

        last_dot = decoded.rfind('.')
        if last_dot != -1 and last_dot > 100:
            # Keep sentence complete
            trimmed_text = decoded[:last_dot+1]
            trimmed_tokens = tokenizer.encode(trimmed_text)
            chunks.append(trimmed_text.strip())
            start += len(trimmed_tokens)
        else:
            # Fallback to hard cut
            fallback_chunk = tokenizer.decode(chunk_tokens, skip_special_tokens=True)
            chunks.append(fallback_chunk.strip())
            start += max_tokens

    return chunks

# Step 3: Apply chunking and generate embeddings
def process_pdf_to_embeddings(pdf_path: str):
    paragraphs = extract_paragraphs(pdf_path)
    print(f"Extracted {len(paragraphs)} paragraphs.")

    all_chunks = []
    for para in paragraphs:
        chunks = chunk_paragraph(para)
        all_chunks.extend(chunks)

    print(f"Total chunks generated: {len(all_chunks)}")

    # Step 4: Convert to vector embeddings
    embeddings = model.encode(all_chunks, convert_to_tensor=True)
    return all_chunks, embeddings

# === Example Usage ===
if __name__ == "__main__":
    pdf_path = "your_file.pdf"  # ⬅️ Replace with your PDF file path
    chunks, embeddings = process_pdf_to_embeddings(pdf_path)

    # Optional: Print sample
    for i, chunk in enumerate(chunks[:3]):
        print(f"\n--- Chunk {i+1} ---\n{chunk}\n")
